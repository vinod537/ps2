<style>

	.contents__002412 {
		text-align: center;
	}
.entry-meta.mb-2.datesdsf.new__sdat .global-list li {
	margin-left: 117px;
	margin-top: -16px;
}


.readpressrealease a {
    color: #ef3c0e;
}

.readpressrealease a:hover {
    color: #ef3c0e;
}

	@media  screen and (min-width:1100px) and (max-width:1500px) {
		.global-list.d-flex.newest {
    margin-left: 0px!important;
}

		.sg-sidebar.theiaStickySidebar .s__00__0 {
			float: left;
			padding-top: 16px !important;
		}

	}

	



	@media  screen and (min-width:320px) and (max-width:767px) {
		.entry-content.p-4.add__class__088 ul {
			padding: 0px 0px 0px 17px !important;
		}

		.mainclasssliderimg {
			text-align: center;
			margin-right: auto;
			margin-left: auto;
		}

		#home-carouselgfgfgfg .btn-success {
			color: #fff;
			background-color: #073c65;
			border-color: #073c65;
			padding: 4px 18px 4px 18px;
			float: left;
			margin-right: 27px;
			margin-top: 24px;
			border-radius: 6px;
			margin-bottom: 55px !important;
		}

		.views__relaed .container {
			width: 91%;
		}

		.paragraph li {
			font-size: 13px;
			line-height: 20px;
			margin-bottom: 13px;
		}

		.views__relaed .container {
			width: 90% !important;
		}

		.views__relaed .owl-nav .owl-prev {
			left: -13px !important;
		}

		.views__relaed .owl-nav .owl-next {
			right: -10px !important;
		}

		.footer.footer-style-1 .play_buttons ul li {
			width: auto !important;
			margin-right: 0px;
		}

		.container {
			max-width: 100%;
		}

		.global-list.d-flex.newest {
			
			margin-top: 13px;
		}

		.global-list.d-flex.newest {
			margin-left: -144px !important;
			margin-top: 13px;
		}
	}

	.views__relaed .s__088f .entry-thumbnail img {
		height: 142px !important;
	}

	#myHeader .entry-title {
		height: auto;
	}

	.entry-meta.mb-2 {
		margin-bottom: 16px !important;
		margin-top: -3px !important;
		margin-left: 20px;
	}

	.sg-section.d__showinnf_-0999 .form-group {
		display: none;
	}

	.widget-newsletter {
		border-radius: 20px;
		background-image: url('../public/site/images/subscribe.png');
		/*	background-color: rgb(255, 255, 255);*/
		box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
		padding: 80px 0;
		text-align: center;
	}

	.sg-page-content .container {
		width: 66%;
	}

	.entry-thumbnail {
		margin-bottom: 24px;
	}

	.post-style-2 .entry-content {
		position: relative;
		bottom: 0;
		left: 0;
		width: 100%;
		color: #fff;
		padding: 20px;
	}

	#myHeader .sg-socail li:nth-child(3) {
		display: none;
	}

	#myHeader .sg-socail li:nth-child(4) {
		display: none;
	}

	#myHeader .sg-socail li:nth-child(5) {
		display: none;
	}

	.post-style-2 .entry-content {
		position: relative !important;
		bottom: 0;
		left: 0;
		width: 100%;
		color: #fff;
		padding: 20px;
	}

	.post-style-2 .entry-content,
	.sg-post .entry-content.absolute {
		position: absolute;
		bottom: 0;
		left: 0;
		padding: 20px;
		z-index: 1;
		color: #fff;
		background: none !important;

		width: 100% !important;
	}

	.post-style-2 .entry-title a {
		color: #000 !important;
	}

	.s__088f .entry-thumbnail img {
		height: 208px;
	}

	.s__088f .sg-post .category ul li a,
	a.read-more {
		color: #fff;
		display: block;
		padding: 0px 16px;
		background-color: #6C6665;
		border-radius: 39px;
		color: #fff !important;
		font-size: 10px;
		letter-spacing: 1px;
	}

	/*
	.sg-sidebar.theiaStickySidebar {
	display: none;
}
*/

	.views__relaed .container {
		width: 66%;
	}

	.views__relaed {
		background: #f4f8fb;
		padding-top: 53px;
	}

	.post-style-2:hover .entry-content,
	.sg-post:hover .entry-content.absolute {
		padding-top: 20px !important;
		background: transparent !important;
		background: transparent !important;
		background: transparent !important;
		background: transparent !important;
	}

	.views__relaed .sg-post {

		box-shadow: 8px 14px 38px rgba(39, 44, 49, .06), 1px 3px 8px rgba(39, 44, 49, .03) !important;
	}

	.post-style-2 .entry-title a {
		color: #000 !important;
		font-size: 12px;
	}

	.views__relaed .section-title {
		margin-bottom: 20px;
		border-bottom: none;
		/* font-size: 32px !important; */
	}

	.views__relaed .section-title h1 {
		font-size: 20px;
		color: #242329;
		font-weight: 500;
		text-transform: capitalize;
		text-decoration: underline;
	}

	.sg-section .d__showinnf_-0999 h1 {
		text-decoration: underline;
		margin-top: 33px;
		display: inline-block;
	}

	.texttt .owl-item {
		padding: 18px;
	}

	.owl-nav {
		display: block !important;
	}


	/* fix blank or flashing items on carousel */
	.owl-carousel .item {
		position: relative;
		z-index: 100;
		-webkit-backface-visibility: hidden;
	}

	/* end fix */
	.owl-nav>div {
		margin-top: -26px;
		position: absolute;
		top: 50%;
		color: #cdcbcd;
	}

	.owl-nav i {
		font-size: 52px;
	}

	.owl-nav .owl-prev {
		left: -30px;
	}

	.owl-nav .owl-next {
		right: -30px;
	}

	.owl-nav .owl-prev {
		left: 6px !important;
	}

	.owl-nav>div {
		margin-top: -26px;
		position: absolute;
		top: 50%;
		color: #cdcbcd;
	}

	.owl-nav .owl-next {
		right: 8px !important;
	}

	.add__banners {
		margin-bottom: 28px;
	}

	.daily__news__pro {
		background: #fff;
	}

	.hdaily_s h3 {
		font-size: 16px;
		color: #222;
		font-weight: 500;
	}

	.loop-item-meta_0 {
		background: #EF3C0E;
		display: inline-block;
		color: #fff;
		padding: 0px 8px 2px 8px;
		border-radius: 34px;
		font-size: 12px;
		margin-top: 7px;
		margin-bottom: 9px;
	}

	.hdaily_s {
		padding: 15px;
	}

	.hdaily_s p {
		font-size: 13px;
	}


	.owl-nav .owl-prev {
		left: -31px !important;
	}

	.owl-nav .owl-next {
		right: -26px !important;
	}

	.widget-title {

		color: #fff !important;

	}

	.widget-newsletter.text-center p {
		color: #fff;
	}

	.sg-widget.widget-social .widget-title {
		display: none;
	}

	.news__lettersd .sg-widget.widget-social {
		display: none;
	}

	.news__lettersd__top .sg-widget.news__0f1245 {
		display: none;
	}

	.news__lettersd__top .container {
		width: 100%;
		max-width: 100%;
	}

	.widget-social ul {

		box-shadow: none !important;
	}

	.list___129 {
		display: none !important;
	}

	.widget-social ul {
		padding: 0px;

	}

	.sg-sidebar.theiaStickySidebar .s__00__0 {
		float: left;
	}

	.c__set__0d {
		float: left;
	}

	.sg-sidebar.theiaStickySidebar .global-list {
		padding: 0px !important;
		margin-left: 24px;
	}

	.sg-sidebar.theiaStickySidebar {
		float: right;
	}

	.news__lettersd__top {
		position: fixed;
		top: 0px;
		background: #fff;
		z-index: 999;
		box-shadow: 0 0 3px 2px #00000017;
		width: 100%;
		padding-top: 13px;
		height: 52px;
	}

	.news__lettersd__top .img-fluid {
		top: 1px;
		width: 166px;
	}

	.sg-sidebar.theiaStickySidebar .sg-widget.widget-social {
		margin-bottom: 0px;
	}

	.sg-sidebar.theiaStickySidebar .widget-social ul li {
		width: 50%;
		float: left;
		margin-bottom: 0px;
		font-size: 12px;
		overflow: hidden;
		text-align: center;
	}

	.widget-social ul li:nth-child(2n+1) {
		padding-right: 0px;
	}

	.news__lettersd__top .entry-title.dse {
		text-align: left;
		color: #000;
		font-size: 19px;
		margin-bottom: 36px;
		font-weight: 600;
	}

	.footer.footer-style-1 {
		float: left;
		width: 100%;
	}

	.news__lettersd {
		float: left;
		width: 100%;
	}

	.news__lettersd__top .widget-social ul li span {
		width: 47px;
		height: 56px;
		line-height: 35px;
		display: block;
		text-align: center;
		color: #fff;
		font-size: 20px;
		float: left;
		padding-top: 18px;
		position: relative;
		/* top: 5px; */
	}

	.news__lettersd__top .sg-socail {
		margin-top: -17px;
		margin-right: -15px;
	}

	.news__lettersd__top .sg-sidebar.theiaStickySidebar .widget-social ul li {
		width: 50%;
		float: left;
		margin-bottom: 0px;
		font-size: 12px;
		overflow: hidden;
		text-align: center;

	}

	.news__lettersd__top .widget-social ul li:nth-child(2n+1) {
		padding-right: 0px;
	}

	.news__lettersd__top .widget-social ul li:nth-child(2n) {
		padding-left: 0px;
	}

	.news__lettersd .sg-sidebar.theiaStickySidebar {
		width: 100%;
	}

	.news__lettersd__top {
		display: none;
	}

	.news__lettersd__top.sticky {
		display: block;
	}

	.global-list.s__00f123 li a {
		color: #000;
		font-size: 32px;
		background: transparent;
		box-shadow: none;
	}

	.socilamedias__123430 {
		float: left;
		width: 100%;
		margin-top: 44px;
	}

	.socilamedias__123430 h3 {
		font-size: 16px;
		color: #000;
		margin-bottom: 22px;
	}

	.post-details .sg-socail li a {

		box-shadow: none !important;
	}

	.sg-page-content .container {
		width: 58%;
	}

	.contents__002412 h3 {
		font-size: 14px;
		font-weight: 500;
	}

	.sg-page-content {
		padding-top: 103px;
	}

	.sg-post {
		position: relative;
		overflow: hidden;
		margin-bottom: 30px;
		background-color: transparent !important;

	}

	.entry-content.p-4.add__class__088 {
		position: relative;
		z-index: 99;
		background: transparent !important;
	}

	.contact-form,
	.sg-comments-area,
	.tagcloud-style-1 {
		padding: 3px;
		background-color: transparent !important;

	}

	.tagcloud-style-1 a {
		border-radius: 20px;
		padding: 5px 20px;
		margin-top: 8px;
		margin-bottom: 8px;
		margin-right: 15px;
		display: inline-block;
		background-color: #eae0e0 !important;
	}

	.post-details .sg-socail li a {
		padding: 5px 15px;
		color: #707070;
		display: block;
		border-radius: 4px;
		background-color: transparent !important;

	}

	.views__relaed {
		background: transparent;
		padding-top: 53px;
	}

	.views__relaed .container {
		width: 58%;
	}

	.owl-carousel .item {
		position: relative;
		z-index: 100;
		-webkit-backface-visibility: hidden;
		background: #fff;
	}

	.news__lettersd {
		float: left;
		width: 100%;
		background: transparent !important;
	}

	.sg-page-content {
		float: left;
		width: 100%;
		background: #fff;
	}

	.views__relaed {
		background: #fff;
		padding-top: 53px;
	}

	.news__lettersd {
		float: left;
		width: 100%;
		background: #fff !important;
	}

	.views__relaed {
		background: #fff;
		padding-top: 53px;
		float: left;
		width: 100%;
	}

	.post-style-2 .entry-title a {
		color: #000 !important;
		font-size: 13px;
		height: 74px;
		display: inline-block;
		margin-top: -31px;
		padding: 0px;
	}

	.post-style-2 .entry-title a {
		color: #333 !important;
		font-size: 17px;
		height: 74px;
		display: inline-block;
		margin-top: -31px;
		padding: 0px;
		text-align: left;
		line-height: 19px;
	}

	.rightads {
		position: fixed;
		right: 101px;
	}

	.leftads {
		position: fixed;
		left: 95px;
	}

	.topads img {
		box-shadow: 0 0 4px 2px #0000004f;
	}

	.leftads img {
		box-shadow: 0 0 2px 3px #0000003d;
	}

	.rightads img {
		box-shadow: 0 0 2px 3px #0000003d;
	}

	.news__lettersd__top .entry-title.dse {
		text-align: left;
		color: #000;
		font-size: 15px;
		margin-bottom: 0px;
		font-weight: 600;
		margin-top: 0px;
	}

	.heading__name12 {
		height: 39px;
		vertical-align: middle;
		display: table-cell;
		position: relative;
		top: -8px;
	}

	.contents__002412 p {
		font-size: 12px;
	}

	.entry-title {
		height: auto;
		margin-bottom: 0px !important;
	}

	.sg-post {
		position: relative;
		overflow: hidden;
		margin-bottom: 0px;

	}

	.entry-title {
		height: auto !important;
	}

	.theiaStickySidebar.post-details .sg-post {
		padding-bottom: 0px !important;
	}

	a.biosimilars {
		background: #64af4c;
	}


	@media  screen and (min-width:768px) and (max-width:1250px) {
		.sg-page-content .container {
			width: 62% !important;
			max-width: 100% !important;
		}

		.views__relaed .container {
			width: 58% !important;
		}

		.views__relaed .container {
			width: 58% !important;
		}

		.post-style-2 .entry-title a {
			color: #333 !important;
			font-size: 12px;
			height: 74px;
			display: inline-block;
			margin-top: -33px;
			padding: 0px;
			text-align: left;
			line-height: 16px;
		}

		.news__lettersd .container {
			width: 67% !important;
		}

		.widget-newsletter {
			border-radius: 20px;
			background-color: rgb(255, 255, 255);
			box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
			padding: 35px 0;
			text-align: center;
		}

		.topads img {
			width: 100% !important;
		}
	}

	a.Top-20 {
		background: #246b8d;
		color: #fff !important;
	}

	a.insight {
		background: #173c3c;
	}

	a.events {
		background: #0a0a0a;
	}
</style>









<?php $__env->startSection('style'); ?>

<link rel="stylesheet" href="<?php echo e(static_asset('site/css/plyr.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(static_asset('reaction/reaction.css')); ?>" />

<link rel="stylesheet" href="<?php echo e(static_asset('reaction/reaction-2.css')); ?>" />

<!--

<div class="header">
  <h2>Scroll Indicator</h2>
  <div class="progress-container">
    <div class="progress-bar" id="myBar"></div>
  </div>  
</div>
-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
// dd($author->first_name);

?>


<section class="news__lettersd__top" id="myHeader">
	<div class="container">




		<div class="row">
			<div class="col-md-2">

				<div class="logo__s_12">
					<a class="navbar-brand align-self-center" href="<?php echo e(route('home')); ?>"><img style="position: relative;
left: -7px;" src="<?php echo e(static_asset(settingHelper('logo'))); ?>" alt="Logo" class="img-fluid"></a>
				</div>
			</div>

			<div class="col-md-8">





				<div class="heading__name12">
					<h3 class="entry-title dse"><?php echo $post->title ?? ''; ?></h3>
				</div>
			</div>
			<div class="col-md-2 col-lg-2">

				<div class="sg-sidebar theiaStickySidebar">
					<div class="s__00__0">
						<span style="text-transform: uppercase;
font-size: 12px;">Share this</span>

					</div>
					<div class="c__set__0d">
						
						<div class="sharethis-inline-share-buttons"></div>
					</div>

				</div>

			</div>
		</div>
	</div>
</section>


<div class="sg-page-content">



	<div class="leftads">
		<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($ads_AdLocations->unique_name == 'single_post_left'): ?>
		<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
		<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
			<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">
		</a>
		<?php endif; ?>

		<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
		<?php echo e($ads_AdLocations->ad->ad_code); ?>

		<?php endif; ?>

		<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
		<div class="textads">
			<?php echo e($ads_AdLocations->ad->ad_text); ?>

		</div>
		<?php endif; ?>
		<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>


	<div class="rightads">
		<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($ads_AdLocations->unique_name == 'single_post_right'): ?>
		<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
		<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
			<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">
		</a>
		<?php endif; ?>

		<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
		<?php echo e($ads_AdLocations->ad->ad_code); ?>

		<?php endif; ?>

		<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
		<div class="textads">
			<?php echo e($ads_AdLocations->ad->ad_text); ?>

		</div>
		<?php endif; ?>
		<?php endif; ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<div class="container articla__details_-09">

		<div class="entry-header mb-4">



			<div class="topads">

				<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($ads_AdLocations->unique_name == 'single_post_top'): ?>
				<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
				<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
					<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">
				</a>
				<?php endif; ?>

				<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
				<?php echo e($ads_AdLocations->ad->ad_url); ?>

				<?php endif; ?>

				<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
				<div class="textads">
					<?php echo e($ads_AdLocations->ad->ad_text); ?>

				</div>
				<?php endif; ?>
				<?php endif; ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

			<div class="entry-thumbnail">

				<?php if($post->layout == 'style_3'): ?>
				<?php echo $__env->make('site.pages.article.partials.detail_image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>

			</div>

		</div>

		<div class="row">

			<div class="col-md-12 col-lg-12 sg-sticky">

				<div class="theiaStickySidebar post-details">

					<div class="sg-section">

						<div class="section-content gdg_-0-09">

							<div class="sg-post">

								<?php if($post->layout =='default'): ?>

								<?php echo $__env->make('site.pages.article.style_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

								<?php elseif($post->layout == 'style_2'): ?>

								<?php echo $__env->make('site.pages.article.style_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

								<?php elseif($post->layout == 'style_3'): ?>

								<?php echo $__env->make('site.pages.article.style_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

								<?php endif; ?>

							</div>

							<!-- <?php if($post->slug2!=null && $post->slug2!=''): ?>
										<h4 style="
											font-size: 16px;
											float: left;
											width: 100%;
											margin-bottom: 20px;
										 "><a target="_blank" href="<?php echo e(route('event.detail', ['id' => $post->slug2])); ?>">Click here to read full press release.</a></h4>
										<?php endif; ?> -->

							<?php if($post->tags!=null): ?>

							<div class="sg-section mb-4 d__showinnf">

								<div class="section-content">

									<div class="section-title">

										<h1><?php echo e(__('tags')); ?></h1>

									</div>



									<div class="tagcloud tagcloud-style-1">

<!-- 
										<?php if(!blank($company_names = explode(',', $post->company_name))): ?>

										<?php $__currentLoopData = $company_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($company_name !=''): ?>
											<a href="#"><?php echo e($company_name); ?></a>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										<?php endif; ?> -->

										<!-- <?php if(!blank($products = explode(',', $post->product))): ?>

										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($product !=''): ?>
										<a href="#"><?php echo e($product); ?></a>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										<?php endif; ?> -->


										<?php if(!blank($tags = explode(',', $post->tags))): ?>

										<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

										<a href="<?php echo e(url('tags/'.trim($tag))); ?>"><?php echo e($tag); ?></a>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										<?php endif; ?>

									</div>

								</div>

								<br>
								<?php
								//dd($author);
								?>
								<div class="section-content">

									<div class="wp-block-image">
										<figure class="alignleft size-full">
											<img src="<?php echo e(url('public/'.$author->profile_image)); ?>" alt="" class="wp-image-65838" style="
											border-radius: 50%;
										">
										</figure>
									</div>

									<p><strong><a href="<?php echo e(url('page/about-us#our_team')); ?>"><?php echo e($author->first_name); ?></a></strong> </p>
									<p><?php echo $author->about; ?></p>

								</div>


								<div class="socilamedias__123430">
									<h3>Share this article on WhatsApp, LinkedIn and Twitter</h3>


									<div class="sg-socail">

										<div class="sharethis-inline-share-buttons"></div>



									</div>
									<!-- ShareThis BEGIN -->

									<!-- ShareThis END -->

								</div>

							</div>

							<?php endif; ?>



							<?php if(settingHelper('inbuild_comment') == 1): ?>

							<div class="sg-section d__showinnf_-0999">

								<div class="section-content">

									<div class="section-title">

										<!--
                                                <h1><?php echo e(__('comment')); ?> / <?php echo e(__('reply_from')); ?></h1>

                                            </div>

                                            <form class="contact-form" name="contact-form" method="post" action="<?php echo e(route('article.save.comment')); ?>">

-->
										<?php echo csrf_field(); ?>

										<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

										<div class="row">

											<div class="col-sm-12">

												<div class="form-group">

													<label for="four"><?php echo e(__('comments')); ?></label>

													<textarea name="comment" required="required" class="form-control" rows="7" id="four" placeholder="this is message..."></textarea>

												</div>

											</div>

										</div>

										<!--
                                                <div class="form-group">

                                                    <?php if(Cartalyst\Sentinel\Laravel\Facades\Sentinel::check()): ?>

                                                        <button type="submit" class="btn btn-primary"><?php echo e(__('post')); ?> <?php echo e(__('comment')); ?></button>

                                                    <?php else: ?>

                                                        <a class="btn btn-primary" href="<?php echo e(route('site.login.form')); ?>"><?php echo e(__('comment')); ?></a>

                                                    <?php endif; ?>

                                                </div>
-->

										</form>

									</div>

								</div>



								<?php if(!blank($comments = data_get($post, 'comments'))): ?>

								<div class="sg-section">

									<div class="section-content">

										<div class="sg-comments-area">

											<div class="section-title">

												<h1><?php echo e(__('comments')); ?></h1>

											</div>

											<?php echo $__env->make('site.post.comment', ["comments" => $comments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

										</div>

									</div>

								</div>

								<?php endif; ?>



								<?php endif; ?>



								<?php if(settingHelper('facebook_comment')==1): ?>

								<div class="fb-comments" data-href="<?php echo e(url()->current()); ?>" data-numposts="5" data-width="100%"></div>

								<?php endif; ?>



								<?php if(settingHelper('disqus_comment')==1): ?>

								<!-- disqus comments -->

								<div class="row">

									<div class="col-md-12">

										<div id="disqus_thread"></div>

										<script>
											var disqus_config = function() {

												this.page.url = "<?php echo e(url()->current()); ?>"; // Replace PAGE_URL with your page's canonical URL variable

												this.page.identifier = "<?php echo e($post->id); ?>"; // Replace PAGE_IDENTIFIER with your page's unique identifier variable

											};



											(function() { // DON'T EDIT BELOW THIS LINE

												var d = document,
													s = d.createElement('script');

												s.src = 'https://<?php echo e(settingHelper('
												disqus_short_name ')); ?>.disqus.com/embed.js';

												s.setAttribute('data-timestamp', +new Date());

												(d.head || d.body).appendChild(s);

											})();
										</script>

										<noscript><a href="https://disqus.com/?ref_noscript"></a></noscript>

										<script id="dsq-count-scr" src="//<?php echo e(settingHelper('disqus_short_name')); ?>.disqus.com/count.js" async></script>

									</div>

								</div>

								<!-- END disqus comments -->

								<?php endif; ?>






							</div>

						</div>

					</div>





				</div>







			</div>

		</div>

	</div>



	<section class="views__relaed">

		<div class="container">

			<?php
			//dd($getAllPosts);
			?>

			<?php if(!blank($getAllPosts)): ?>

			<div class="sg-section s__088f">

				<div class="section-content">

					<div class="section-title">

						<h1><?php echo e(__('Related News/Articles')); ?></h1>

					</div>

					<div class="row text-center texttt">
						<div class="owl-carousel">
							<?php $__currentLoopData = array_slice($getAllPosts,0,10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



							<div class="item">

								<div class="sg-post post-style-2">

									<div class="entry-header">

										<div class="entry-thumbnail">


											<a href="<?php if($item->old_id): ?> <?php echo e(route('article.detail', ['id' => $item->old_id, 'slug' => $item->slug])); ?> <?php else: ?> <?php echo e(route('article.detail', ['id' => $item->id, 'slug' => $item->slug])); ?> <?php endif; ?>">
												<?php if(isFileExist(@$item->image, $result = @$item->image->original_image)): ?>
												<?php

												// dd(static_asset($item->image->medium_image));
												?>

												<img src="<?php echo e(static_asset($item->image->original_image)); ?>" data-original="<?php echo e(basePath(@$item->image)); ?>/<?php echo e($result); ?>" alt="<?php echo $item->title; ?>">

												<?php else: ?>

												<img class="img-fluid" src="<?php echo e(static_asset('default-image/default-358x215.png')); ?> " alt="<?php echo $item->title; ?>">

												<?php endif; ?>

											</a>

										</div>

										<?php if($item->post_type=="video"): ?>

										<div class="video-icon large-block">

											<img src="<?php echo e(static_asset('default-image/video-icon.svg')); ?> " alt="video-icon">

										</div>

										<?php elseif($item->post_type=="audio"): ?>

										<div class="video-icon large-block">

											<img src="<?php echo e(static_asset('default-image/audio-icon.svg')); ?> " alt="audio-icon">

										</div>

										<?php endif; ?>

										<div class="category block">

											<ul class="global-list">

												<?php

												if ($item->category_id) {
													$categoryids = json_decode($item->category_id);
													foreach ($categoryids as $category) {
														$dataCat = 	\Modules\Post\Entities\Category::find($category);
												?>
														<li><a class="<?php echo e($dataCat->slug); ?>" href="<?php echo e(url('category',$dataCat->slug)); ?>"><?php echo e($dataCat->category_name); ?></a></li>

												<?php
													}
												}
												?>

												<?php if(isset($item->category->category_name)): ?>

												<!-- <li><a class="<?php echo e($item->category->slug); ?>"  href="<?php echo e(url('category',$item->category->slug)); ?>"><?php echo e($item->category->category_name); ?></a></li> -->

												<?php endif; ?>
												

											</ul>

										</div>

									</div>

									<div class="entry-content">

										<h3 class="entry-title">
											<a href="<?php if($item->old_id): ?> <?php echo e(route('article.detail', ['id' => $item->old_id, 'slug' => $item->slug])); ?> <?php else: ?> <?php echo e(route('article.detail', ['id' => $item->id, 'slug' => $item->slug])); ?> <?php endif; ?>"><?php echo $item->title ?? ''; ?> </a>


										</h3>

										

									</div>

									<div class="entry-meta mb-2">
										<ul class="global-list">

											<li><?php echo e($item->updated_at->format('F j, Y')); ?></li>
										</ul>
									</div>

								</div>

							</div>



							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>
					</div>
				</div>

			</div>

			<?php endif; ?>
		</div>
	</section>
	

	<div class="modal fade" id="newsletterpopup" role="dialog" aria-modal="true" >
        <div class="modal-dialog">
        
        <div class="modal-content">
            <div class="modal-header">
                <h3> Liked our insights or summarized news?</h3>
                <p>Subscribe to our Daily/Weekly newsletter</p>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('subscribe1.newsletter')); ?>" class="tr-form" method="POST">
            <?php echo csrf_field(); ?>

            <div class="radio">
                <label> First Name</label>
                <input type="text" class="first_name form-control" required id="first_name" placeholder="First Name"  value="" name="first_name">
            </div>

            <div class="radio">
                <label> Last Name </label>
                <input type="text" class="last_name form-control" required id="last_name"  placeholder="Last Name" value="" name="last_name">
            </div>
            <div class="radio">
                <label>
                    <input type="checkbox" class="nessleeter" id="daily"  value="daily" name="newsletter_type[]" checked>
                    Daily Newsletter
                </label>
            </div>
            <div class="radio">
            <label>
                <input type="checkbox" class="nessleeter"  id="weekly"    value="weekly" name="newsletter_type[]">
                Weekly Newsletter
            </label>
                
            </div>
                        <label class="checkbox-inline">
            <input type="checkbox" required value="">I agree to the privacy policy and terms.(<a href="<?php echo e(url('/')); ?>/app-privacy-policy">Link</a>)
            </label>
                    <div class="submit_button">

            <input name="email" id="popupemail" type="hidden" class="form-control" placeholder="<?php echo e(__('email_address')); ?>" required>
            <input type="submit" value="Subscribe">

        
        </div>
            </form>
            </div>

        </div>
        
        </div>
    </div>


          
<script>
  
  //   $(document).ready(function() {
  //       $('#myModal').modal('show');
  //   });
  </script>
  
	<section class="news__lettersd" id="news__lettersdSingle">
		<div class="container">


			<div class="col-md-12 col-lg-12 ">

				<div class="sg-sidebar theiaStickySidebar">
					
					<?php echo $__env->make('site.partials.right_sidebar_widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

				</div>

			</div>
		</div>
	</section>

	<div class="popup__show">
		<div class="s__0544">
			X
		</div>
		<div class="popup__all__contents">

			<div class="img__0912">
				<img src="<?php echo e(url('/')); ?>/public/site/images/subscribe_now.png" />
			</div>

			<div class="contents__002412">
				<h3>Liked our insights or summarized news?</h3>
				<p>Subscribe to our Daily/Weekly newsletter</p>
				<p class="readmore__097"><a href="#news__lettersdSingle">Subscribe</a></p>
			</div>
		</div>

	</div>


	<input type="hidden" id="url" value="<?php echo e(url('/')); ?>">

	<input type="hidden" id="post_id" value="<?php echo e($post->id); ?>">



	<?php $__env->stopSection(); ?>



	<?php $__env->startSection('player'); ?>

	<script src="<?php echo e(static_asset('site/js')); ?>/plyr.js"></script>

	<script src="<?php echo e(static_asset('site/js')); ?>/plyr_ini.js"></script>

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('script'); ?>



	<script>
		$(".emoji-2").on("click", function() {

			var url = $('#url').val();



			$('[data-toggle="tooltip"]').tooltip();



			var formData = {

				data_reaction: $(this).attr("data-reaction"),

				id: $('#post_id').val()

			};



			// get section for student

			$.ajax({

				type: "GET",

				data: formData,

				dataType: 'json',

				url: url + '/' + 'post/reaction',

				success: function(data) {



					console.log(data['reactions']);

					console.log(data['is_you']);



					if (data['total'] == 0) {



						$('.like-details').html('Like');



					} else if (data['is_you'] != null) {



						var total = data['total'] - 1;



						$('.like-details').html(' you and ' + total + ' others');



					} else {



						$('.like-details').html(data['total'] + ' others');



					}



					console.log(data['is_you']);



					if (data['is_you'] == null || data['is_you']['data_reaction'] == 'Like') {

						$('.like-emo span').removeAttr('class');

						$('.like-emo span').attr('class', 'like-btn-like');

					} else if (data['is_you']['data_reaction'] == 'Love') {

						$('.like-emo span').removeAttr('class');

						$('.like-emo span').attr('class', 'like-btn-love');

					} else if (data['is_you']['data_reaction'] == 'HaHa') {

						$('.like-emo span').removeAttr('class');

						$('.like-emo span').attr('class', 'like-btn-haha');

					} else if (data['is_you']['data_reaction'] == 'Wow') {

						$('.like-emo span').removeAttr('class');

						$('.like-emo span').attr('class', 'like-btn-wow');

					} else if (data['is_you']['data_reaction'] == 'Sad') {

						$('.like-emo span').removeAttr('class');

						$('.like-emo span').attr('class', 'like-btn-sad');

					} else if (data['is_you']['data_reaction'] == 'Angry') {

						$('.like-emo span').removeAttr('class');

						$('.like-emo span').attr('class', 'like-btn-angry');

					}



					jQuery.each(data['reactions'], function(key, val) {



						if (key == "Like") {

							$('.emo-like-2').attr('data-original-title', 'Like ' + val);

						}

						if (key == "Love") {

							$('.emo-love-2').attr('data-original-title', 'Love ' + val);

						}

						if (key == "HaHa") {

							$('.emo-haha-2').attr('data-original-title', 'HaHa ' + val);

						}

						if (key == "Wow") {

							$('.emo-wow-2').attr('data-original-title', 'Wow ' + val);

						}

						if (key == "Sad") {

							$('.emo-sad-2').attr('data-original-title', 'Sad ' + val);

						}

						if (key == "Angry") {

							$('.emo-angry-2').attr('data-original-title', 'Angry ' + val);

						}



					});





					var reactions = ['Like', 'Love', 'HaHa', 'Wow', 'Sad', 'Angry'];



					jQuery.each(reactions, function(key, val) {



						if (!data['reactions'].hasOwnProperty(val)) {

							$('.emo-' + val.toLowerCase() + '-2').attr('data-original-title', val + ' 0');

						}



					});



					$('[data-toggle="tooltip"]').tooltip();





				},

				error: function(data) {

					// console.log('Error:', data);

				}

			});

		});



		$(document).ready(function() {

			$('[data-toggle="tooltip"]').tooltip();

		});
	</script>


	<script>
		window.onscroll = function() {
			myFunction()
		};

		var header = document.getElementById("myHeader");
		var sticky = header.offsetTop;

		function myFunction() {
			if (window.pageYOffset > sticky) {
				header.classList.add("sticky");
			} else {
				header.classList.remove("sticky");
			}
		}
	</script>
	<style>
		.section-content.gdg_-0-09 .sg-post {
			padding-bottom: 0px !important;
		}

		.sg-section.s__088f .sg-post .entry-content {
			padding: 17px 13px;
			font-size: 13px;
			height: 102px;
			/* overflow: hidden; */
		}

		.sg-section.s__088f .entry-meta.mb-2 {
			margin-bottom: 16px !important;
			margin-top: 1px !important;
			margin-left: 14px;
		}


		@media  screen and (min-width:320px) and (max-width:767px) {

			.news__lettersd .container {
				width: 100%;
			}

			.widget-newsletter {
				border-radius: 20px;
				background-color: rgb(255, 255, 255);
				box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
				padding: 18px 0;
				text-align: center;
			}

			.tr-form {
				width: 95% !important;
				margin-left: auto;
				margin-right: auto;
			}

			.sg-sidebar.theiaStickySidebar {
				margin-top: -45px !important;
				padding-right: 0px !important;
			}

			.news__lettersd {
				margin-top: 46px;
			}
		}
	</style>

<style>
   
    
   .form-control::placeholder {
 color: #6c757d;
 opacity: 1;
background:transparent!important;
}
	 @media  screen and (min-width:1100px) and  (max-width:1550px){
.search-form.d__rtt.new_drtt {
 position: absolute;
 top: 28px!important;
 right: -27px!important;
}
		 .fa.fa-search {
 position: relative;
 top: 0px!important;
}
 }
 @media  screen and (min-width:1100px) and (max-width:1450px){
	  .daily_img .img-fluid {
height: auto!important;
border-radius: 6px 6px 0px 0px;
width: 100%;
}
	 .form-control::placeholder {
 color: #6c757d;
 opacity: 1;
background:transparent!important;
}
 }
.sg-sidebar__theiaStickySidebar p {
 display: block;
 font-size: 12px !important;
 color: #000 !important;
 /* background: #fff; */
 margin-top: -15px;
 padding-left: 10px;
}
 .modal-body .tr-form {
 width: 60%;
 margin-left: auto;
 margin-right: auto;
 width: 100% !important;
}
 .banners4 .img__banners img {
 width: 100%!important;
 max-width: 121%;
 margin-left: -25px!important;
 margin-top: 30px!important;
}
 .b__9656.homenewsletterclick {
 position: relative;
 left: 17px !important;
 top: -72px;
 float: right;
	 z-index:9999;
}
 .banners2 .img__banners img {
 width: 100%!important;
 margin-top: 20px;
}
 .banners3 .l__contents1 {
 margin-top: 78px;
 width: 100%!important;
}
 .banners3 img {
 width: 85% !important;
 margin-top: 50px;
}
 .banners4 .l__contents1 {
 margin-top: 27px;
 width: 100%!important;
}
 .add__banners {
 margin-bottom: 28px;
 margin-top: 40px;
}
 .add__banners .container {
 width: 80%;
}
	 .alert-success {
 color: #155724;
 background-color: #d4edda;
 border-color: #c3e6cb;
 z-index: 9999;
}
 .alert {
 position: relative;
 padding: 0.75rem 1.25rem;
 margin-bottom: 1rem;
 border: 1px solid transparent;
 border-radius: .25rem;
 position: relative;
 top: 22px;
}
 .news__letter.form__tr .container {
 width: 66% !important;
}
 .categories__list__s .container {
 width: 88%;
}
.daily__new .container {
 max-width: 72%!important;
}
 .topads {
 padding-bottom: 45px;
}
.leftads {
 position: fixed;
 left: 59px;
}
.rightads {
 position: fixed;
 right: 63px;
}
.medium-post-style-1, .post-style-1 {

 display: inline-block!important;
}
 .sg-post.medium-post-style-1 {
 width: 100%;
}
 .medium-post-style-1 .entry-thumbnail {
 width: 100%;
}
 body {
 background: #f2f2f2;
}
 
 .banner__s.d__059i.new_slider .container {
 width: 85%;
} 
 
 .sg-sidebar__theiaStickySidebar #homenews {
 width: 70%;
}
 @media  screen and (min-width:1100px) and (max-width:1500px) {

	 .b__9656.homenewsletterclick {
 position: relative;
 left: 27px !important;
 top: -72px;
 float: right;
 z-index: 9999;
}
	 
	 .mainclasssliderimg ul li {
 width: 35%;
 display: inline-block;
 margin-right: 10px;
}
}
 .sg-main-content.mb-4 {
 min-height: 400px;
}
 .sg-main-content.mb-4 {
 margin-top: 125px;
}
 .l__contents1 .tr-form #news {
 background: #fff !important;
}
.tr-form #news {
 background: rgb(233, 227, 254) !important;
}

.carousel-wrap {
margin: 90px auto;
padding: 0 5%;
width: 80%;
position: relative;
}
.banner__s .col-lg-12 {
padding: 0px;
}
.banner__s {
margin-top: -31px;
}
.sg-menu.menu-style-1 {
position: relative;
z-index: 99;
}
/* fix blank or flashing items on carousel */
.owl-carousel .item {
position: relative;
z-index: 100; 
-webkit-backface-visibility: hidden; 
}
/* end fix */
.owl-nav > div {
margin-top: -26px;
position: absolute;
top: 50%;
color: #cdcbcd;
}
.owl-nav i {
font-size: 52px;
}
.owl-nav .owl-prev {
left: -30px;
}
.owl-nav .owl-next {
right: -30px;
}
.owl-nav .owl-prev {
left: 6px!important;
}
.owl-nav > div {
margin-top: -26px;
position: absolute;
top: 50%;
color: #cdcbcd;
}
.owl-nav .owl-next {
right: 8px!important;
}
.add__banners {
margin-bottom: 28px;
}
.daily__news__pro {
background: #fff;
}
.hdaily_s h3 {
font-size: 16px;
color: #222;
font-weight: 500;
}
.loop-item-meta_0 {
background: #EF3C0E;
display: inline-block;
color: #fff;
padding: 0px 8px 2px 8px;
border-radius: 34px;
font-size: 12px;
margin-top: 7px;
margin-bottom: 9px;
}
.hdaily_s {
 padding: 15px;
 height: 200px;
}
.hdaily_s p {
font-size: 13px;
}
.all__heading {
margin-bottom: 20px;
margin-top: 37px;
}
.all__heading h3 {
color: #000;
font-size: 20px;
}
.all__heading::before {
content: "";
background: #0000004a;
height: 1px;
width: 88%;
display: inline-block;
float: right;
position: relative;
top: 21px;
}
.sg-home-section {
display: none;
}
.daily__new {
margin-bottom: 44px;
}
.a__bac__l {
border-radius: 20px;
background-color: rgb(255, 255, 255);
box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
padding: 80px 0;
text-align: center;
}
.forum__group input {
background: rgb(233, 227, 254);
border: 1px solid #0000001c;
padding: 9px;
font-size: 15px;
width: 32%;
border-radius: 7px;
margin-bottom: 17px;
}
.sub {
background: #EF3C0E;
border: none;
color: #fff;
padding: 7px 30px 7px 30px;
border-radius: 7px;
}
.a__bac__l h3 {
color: #000;
margin-bottom: 16px;
}
.a__bac__l p {
text-transform: uppercase;
letter-spacing: 1px;
margin-top: 23px;
margin-bottom: 23px;
}
.list__categories__list li {
list-style: none;
}
.list__categories__list {
padding: 7px;
}
.list__categories__li_sting {
background: #fff;
padding: 6px;
border-radius: 5px;
}
.static_09 h3 {
font-size: 14px;
color: #000;
padding: 10px;
margin-bottom: 0px;
}
.list__categories__list li {
display: inline-block;
width: 19.7%;
padding: 5px;
}
.sg-main-content.mb-4 {
display: none;
}
.all__heading h3 {
color: #000;
font-size: 20px;
text-transform: uppercase;
}
.hdaily_s h3 {
font-size: 13px;
color: #222;
font-weight: 400;
line-height: 20px;
}
.categories__list__s {
padding-bottom: 36px;
padding-top: 16px;
}
.static_09 h3 {
font-size: 14px;
color: #000;
padding: 10px;
margin-bottom: 0px;
font-weight: 500;
line-height: 19px;
}
.daily__new {
margin-bottom: 44px;
margin-top: 62px;
}
.all__heading {
margin-bottom: 33px;
margin-top: 37px;
text-align: center;
}
.banner__s {
padding: 13px 26px 23px 26px!important;
}
.img__08 img {
width: 100px;
height: 100px;
border-radius: 72%;
margin-left: auto;
margin-right: auto;
}
.img__08 {
text-align: center;
}
.list__categories__li_sting {
background: transparent;
padding: 6px;
border-radius: 5px;
}
.static_09 {
text-align: center;
}
.static_09 h3 {
font-size: 14px;
color: #000;
padding: 10px;
margin-bottom: 0px;
font-weight: 500;
line-height: 19px;
letter-spacing: 1px;
}
.daily_img .img-fluid {
height: 165px;
border-radius: 6px 6px 0px 0px;
}
.list__categories {

margin-left: auto;
margin-right: auto;
}
.list__categories__li_sting {
margin-bottom: 18px;
}
.exccinte{
text-align: center;
}
.view__all__09 {
text-align: center;
}
.view__all__09 span {
border: none;
padding: 5px 26px 7px 26px;
border-radius: 36px;
background:rgba(34, 54, 102, 0.98);
color: #fff;
font-size: 13px;
}
.img__08 img {
 width: 150px;
 height: 150px;
 border-radius: 72%;
 margin-left: 11px;
 margin-right: auto;
 padding: 25px;
 border: 1px solid #0003;
 background: #fff;
 margin-top: -201px;
}
 .static_09 {
 text-align: center;
 margin-top: -27px;
 margin-left: 18px;
}
.daily__news__pro {
background: #fff;
border-radius: 6px;
box-shadow: 0px 0px 20px 6px rgba(107, 83, 254, 0.1);
}
.sg-widget.widget-social {
display: none;
}
.tr-form {
width: 50%!important;
margin-left: auto;
margin-right: auto;
}
#news {
background: rgb(233, 227, 254);
  border: 1px solid #989a9f70 !important;
padding: 9px;
font-size: 15px;
width: 74%!important;
border-radius: 7px;
margin-bottom: 17px;
}
.daily__new .container {
max-width: 72%;
}
.hdaily_s h3 {
 font-size: 17px;
 color: #222;
 font-weight: 400;
 line-height: 23px;
 color: #000 !important;
 height: 124px;
}
.footer-content .sg-socail li a {
width: 35px;
height: 35px;
line-height: 32px;
display: block;
text-align: center;
border-radius: 100%;
color: #333;
font-size: 15px;
border: 1px solid #3d9be140;
line-height: 3px !important;
}
.sg-socail {
margin-left: -127px;
}
.daily_img .img-fluid {
height: 227px;
border-radius: 6px 6px 0px 0px;
width: 100%;
}
.daily__news__pro {
background: #fff;
border-radius: 6px;
box-shadow: 0px 0px 20px 6px rgba(107, 83, 254, 0.1);
margin-bottom: 26px;
}
.second.circle {
position: relative;
margin-left: 47px;
}
@media  screen and (min-width:1100px) and (max-width:1550px){
.second.circle {
position: relative;
margin-left: 38px;
}
	.col-md-2asfasf .search-form.d__rtt {
 right: 3px !important;
}
}
.sg-sidebar__theiaStickySidebar .widget-title {
display: none;
}
.sidebar__theiaStickySidebar p {
display: none;
}

.sg-sidebar__theiaStickySidebar .widget-newsletter {
border-radius: 17px;
background-color: transparent;
box-shadow: none;
padding: 13px 0;
text-align: center;
}
.sg-sidebar__theiaStickySidebar .tr-form {
width: 70% !important;
margin-left: 0px;
margin-right: auto;
}
.banner__sectionss {
padding-top: 95px;
}
.l__contents1 {
width: 94%;
padding-top: 57px;
}
.s__09d_0.exccinte .item img {
/* width: 68%; */
margin-top: 26px;
}
.all__heading::before {
content: "";
background: transparent!important;
height: 1px;
width: 100%;
display: inline-block;
float: right;
position: relative;
top: 16px;
}
.all__heading h3 {
 color: #073C65;
 font-size: 72px;
 text-transform: uppercase;
}
.hdaily_s h3 a {
color: #333;
font-size: 17px;
font-weight: 600;
}
.loop-item-metad_0 {
margin-top: 28px;
color: #777;
font-size: 14px;
}
.widget-newsletter.text-center {
background:url(<?php echo e(static_asset('site/images/back.jpg')); ?>);
}
.news__letter .container {
max-width: 72%;
}
.widget-newsletter.text-center {
 text-align: center !important;
 color: #fff;
 padding-left: 0px;
}
.widget-newsletter .widget-title {
font-weight: 500;
color: #fff;
font-size: 27px;
padding: 8px 0px;
margin-bottom: 20px;
text-transform: uppercase;
background-color: transparent;
}
.widget-newsletter .tr-form {
width: 60%;
margin-left: auto;
margin-right: auto;
}
#news {
background: transparent!important;
  border: 1px solid #989a9f70 !important;
padding: 11px;
font-size: 15px;
width: 70%;
border-radius: 7px;
margin-bottom: 17px;
}
#news .form-control {
height: 57px;
border-radius: 4px;
padding: 6px 20px;
margin-bottom: 30px;
border: 1px solid #d8e2e9;
}
.widget-newsletter .widget-title {
font-weight: 600;
color: #fff;
font-size: 30px;
padding: 24px 0px;
margin-bottom: 20px;
text-transform: uppercase;
background-color: transparent;
}
.widget-newsletter.text-center {
background-size: cover;
}
.banner__sectionss .widget-newsletter.text-center {
background: transparent;
padding-left: 0px;
}
.banner__sectionss .sg-sidebar__theiaStickySidebar .tr-form {
width: 94% !important;
margin-left: 0px;
margin-right: auto;
}
.banner__sectionss #news {
background: rgb(233, 227, 254);
border: 1px solid #989a9f70 !important;
padding: 9px;
font-size: 15px;
width: 70%;
border-radius: 7px;
margin-bottom: 17px;
}
.second.circle {
 position: relative;
 margin-left: 9px;
 margin-top: -5px;
 top: -6px;
}
canvas {
width: 159px;
}
.banner__sectionss {
padding-top: 123px;
margin-bottom: 53px;
}
.daily__new {
margin-bottom: 44px;
margin-top: 88px;
}
.view__all__09 span {
border: none;
padding: 14px 38px 13px 38px;
border-radius: 10px;
background:#073c65;
color: #fff;
font-size: 13px;
text-transform: uppercase;
font-size: 19px;
margin-top: 42px;
display: inline-block;
margin-bottom: 22px;
cursor: pointer;
} 
 
 .showless__0 span {
border: none;
padding: 14px 38px 13px 38px;
border-radius: 10px;
background:#073c65;
color: #fff;
font-size: 13px;
text-transform: uppercase;
font-size: 19px;
margin-top: 42px;
display: inline-block;
margin-bottom: 22px;
cursor: pointer;
}
 

.banner__s.d__059i .widget-newsletter.text-center {
background: transparent;
padding-left: 0px;
}
.banner__s.d__059i  .sg-sidebar__theiaStickySidebar .tr-form {
width: 96% !important;
margin-left: 0px;
margin-right: auto;
}
.banner__s.d__059i {
padding-top: 143px !important;
padding-bottom: 75px !important;
}
 
 .cont__yr {
 padding-left: 16px;
 margin-right: 14px;
}
 
 .cont__yr li {
 font-size: 14px;
 margin-bottom: 4px;
}
 .cont__yr {
 margin-bottom: 32px;
}
 .s_dd {
 margin-top: -34px;
}
 
 .l__contents1 p {
 font-size: 14px;
 color: #000;
}
 .l__contents1 i {
 font-size: 13px;
}
 
 .banners2 .img__banners img {
 width: 85%;
}
 
 .banners2 .l__contents1 {
 margin-top: 74px;
}
 
 .banners3 .l__contents1 {
 margin-top: 78px;
 width: 76%;
}
 
 .banners4 .l__contents1 {
 margin-top: 27px;
 width: 77%;
}
 
  .banners4 .img__banners img {
 width: 117% !important;
 max-width: 121%;
 margin-left: -72px;
}
 
 .banners1 .img__banners img {
 max-width: 114%;
 width: 123% !important;
 margin-left: -31px;
}
 
#home-carouselgfgfgfg .btn-success {
 color: #fff;
 background-color:#073c65;
 border-color: #073c65;
 padding: 8px 27px 9px 27px;
 float: left;
 margin-right: 27px;
 margin-top: 24px;
 border-radius: 6px;
}
 .banner__s.d__059i {
 padding-top: 128px !important;
 padding-bottom: 0px !important;
	 height:101vh;
}
.item.banners1 {
 padding-top: 66px;
}   
 .widget-newsletter.text-center {
 
 background-size: 100% 100% !important;
}
 .mainclasssliderimg ul li {
 width: 35%;
 display: inline-block;
}
 .mainclasssliderimg ul {
 padding: 0px;
 margin-top: 35px;
}
 .banners3 img {
 width: 85%!important;
}
 
.s__09d_0.exccinte .item img {
 width: 100% !important;  
 margin-top: 26px;
 border-radius: 11px;
 box-shadow: 0 0 6px 5px #0000000a;
}   

 .showless__0 {
 text-align: center;
 
}
 .showless__0 {
 display: none;
}
 @media  screen and (min-width:320px) and (max-width:767px){
	 .sg-sidebar__theiaStickySidebar #homenews {
 width: 59%!important;
}

 .loop-item-metad_0 {
 margin-top: 46px;
 color: #777;
 font-size: 14px;
}
	
 }
   .modal-dialog {
 max-width: 558px;
 margin: 10.75rem auto;
}
 .modal-header {
 display: -ms-flexbox;
 display: block;
 -ms-flex-align: start;
 align-items: flex-start;
 -ms-flex-pack: justify;
 justify-content: space-between;
 padding:0px!important;
 border-bottom: none!important;
 border-top-left-radius: .3rem;
 border-top-right-radius: .3rem;
}
 .modal-header .close {
 padding: 1rem 1rem;
 margin: -1rem -1rem -1rem auto;
 position: relative;
 top: -78px !important;
}
 .modal-header h3 {
 color: #000;
 font-size: 22px;
 
}
 .modal-header p {
 font-size: 15px !important;
 color: #000;
}
 .submit_button input {
 width: 100%;
 border-radius: 3px;
 background: #073c65;
 padding-bottom: 9px;
 margin-top: 25px;
}
 .modal-content {
 padding: 18px;
}
 .modal-body {
 margin-top: -13px;
}
 .radio {
 margin-bottom: 10px;
	 color:#000;
}
 .radio input {
 margin-right: 10px;
 font-size: 13px!mportant;
}
 .checkbox-inline input {
 margin-right: 10px;
}
 .checkbox-inline{
	 color:#000;
 }
.submit_button input {
 background: #073c65;
 border: #073c65;
 color: #fff;
 border-radius: 10px;
 padding: 4px 20px;
 margin-top: 7px;
}
 .submit_button {
 text-align: center;
}
 .new_popupbutton {
/*	display: none !important;*/
  opacity:0;   
}
   .banner__s.d__059i.new_slider .banners4 .img__banners img {
 width: 100% !important;
 max-width: 121%;
 margin-left: -72px;
 margin-top: 59px;
}
 @media  screen and (min-width:1100px) and (max-width:1450px){
 .banner__s.d__059i.new_slider .banners3 img {
 width: 90% !important;
 max-width: 114%;
}
	 .loop-item-metad_0 {
 margin-top: 37px;
 color: #777;
 font-size: 14px;
}
.banner__s.d__059i.new_slider .banners2 .img__banners img {
 width:90% !important;
 max-width: 114%;
 margin-left: -15px;
}
	.banner__s.d__059i.new_slider .banners2 .l__contents1 {
 margin-top: 37px;
}
	.banner__s.d__059i.new_slider .banners4 .img__banners img {
 width: 100% !important;
 max-width: 121%;
 margin-left: -72px;
 margin-top: 59px;
}
	 .cont__yr {
 padding-left: 20px!important;
 margin-right: 14px;
}
 }
 
 
 
 
 canvas{
	 height:151px!important;
	 width:151px!important;
 }
 
 
 @media  screen and (min-width:320px) and (max-width:767px) {
	 #home-carouselgfgfgfg .btn-success {
 color: #fff;
 background-color: #073c65;
 border-color: #073c65;
 padding: 4px 18px 4px 18px;
 float: left;
 margin-right: 0px;
 margin-top: 24px;
 border-radius: 6px;
 margin-bottom: 55px;
 margin-left: 26px!important;
}
	 .l__contents1 p {
 font-size: 12px;
 color: #333;
 line-height: 20px;
 margin-left: 42px!important;
}
	 .banner__s.d__059i.new_slider .container {
 width: 100%;
 max-width: 100%;
}
	 .newhead_new h1 {
 margin-bottom: 41px !important;
}
.l__contents1 {
 width: 94%;
 padding-top: 10px;
}
	 .banner__s.d__059i {
 padding-top: 108px !important;
 padding-bottom: 0px !important;
 height: auto;
}
	 .l__contents1 p {
 font-size: 12px;
 color: #333;
 line-height: 20px;
}
	 #home-carouselgfgfgfg .btn-success {
 color: #fff;
 background-color: #073c65;
 border-color: #073c65;
 padding: 4px 18px 4px 18px;
 float: left;
 margin-right: 27px;
 margin-top: 24px;
 border-radius: 6px;
}
	 .daily__new .container {
 max-width: 92% !important;
}
	 .categories__list__s .container {
 width: 100%;
 max-width: 100%;
}
	 .img__08 img {
 width: 150px;
 height: 150px;
 border-radius: 72%;
 margin-left: -8px;
 margin-right: auto;
 padding: 25px;
 border: 1px solid #0003;
 background: #fff;
 margin-top: -169px;
}
	 .footer.footer-style-1 .play_buttons ul li {
 width: auto!important;
 margin-right: 0px;
}
	 .daily__new {
 margin-bottom: 0px;
 margin-top: 88px;
}
	 .mainclasssliderimg ul li {
 width: 46%;
 display: inline-block;
 margin-left: 0px;
 margin-top: -48px;
}
	 .banners4 {
 margin-bottom: 24px;
}
	 .add__banners .container {
 width: 100%;
 max-width: 100%;
 padding: 0px;
}
	 .b__9656.homenewsletterclick {
 position: relative;
 left: 11px !important;
 top: -74px;
 float: right;
 z-index: 9999;
 height: 42px;
}
	 .b__9656 {
 background: #073c65 !important;
 border: none;
 color: #fff !important;
 padding: 7px 15px 7px 15px !important;
 border-radius: 7px !important;
}
	 .paragraph li {
 font-size: 13px;
 line-height: 20px;
 margin-bottom: 13px;
}
.static_09 {
 text-align: center;
 margin-top: -27px;
 margin-left: 0px;
}
	 .static_09 h3 {
 font-size: 14px;
 color: #000;
 padding: 2px;
 margin-bottom: 0px;
 font-weight: 500;
 line-height: 19px;
 letter-spacing: 1px;
}
	 .sg-socail {
 margin-left: -7px;
 margin-top: 11px;
 margin-bottom: 55px !important;
}
 }
</style>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/site/pages/article_detail.blade.php ENDPATH**/ ?>