<?php echo $templateBody; ?>

<?php /**PATH /var/www/html/Modules/Setting/Providers/../Resources/views/email/email_template.blade.php ENDPATH**/ ?>