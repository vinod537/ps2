<style>
   
    
      .form-control::placeholder {
	color: #6c757d;
	opacity: 1;
background:transparent!important;
}
        @media  screen and (min-width:1100px) and  (max-width:1550px){
                  .item.banners1 
  .img__banners {
    margin-top: 110px!important;
}
    .item.banners2 .img__banners {
    margin-top: 134px!important;               
}
    .item.banners3 
 .img__banners {
    margin-top: 125px!important;
}
    .item.banners4 
 .img__banners {
    margin-top: 214px!important;
}
   .search-form.d__rtt.new_drtt {
    position: absolute;
    top: 28px!important;
    right: -27px!important;     
}
            .fa.fa-search {
	position: relative;
	top: 0px!important;
}
    }
    @media  screen and (min-width:1100px) and (max-width:1450px){
         .daily_img .img-fluid {
   height: auto!important;
   border-radius: 6px 6px 0px 0px;
   width: 100%;
   }
        .form-control::placeholder {
	color: #6c757d;
	opacity: 1;
background:transparent!important;
}   
    }  
 .sg-sidebar__theiaStickySidebar p {
	display: block;
	font-size: 12px !important;
	color: #000 !important;
	/* background: #fff; */
	margin-top: -15px;
	padding-left: 10px;
}
    .modal-body .tr-form {
	width: 60%;
	margin-left: auto;
	margin-right: auto;
	width: 100% !important;
}
    .banners4 .img__banners img {
	width: 100%!important;
	max-width: 121%;
	margin-left: -25px!important;
	margin-top: 30px!important;
}
    .b__9656.homenewsletterclick {
	position: relative;
	left: 17px !important;
	top: -72px;
	float: right;
        z-index:9999;
}
    .banners2 .img__banners img {
	width: 100%!important;
	margin-top: 20px;
}
    .banners3 .l__contents1 {
	margin-top: 78px;
	width: 100%!important;
}
    .banners3 img {
	width: 85% !important;
	margin-top: 50px;
}
    .banners4 .l__contents1 {
	margin-top: 27px;
	width: 100%!important;
}
    .add__banners {
	margin-bottom: 28px;
	margin-top: 40px;
}
    .add__banners .container {
	width: 80%;
}
        .alert-success {
	color: #155724;
	background-color: #d4edda;
	border-color: #c3e6cb;
	z-index: 9999;
}
    .alert {
	position: relative;
	padding: 0.75rem 1.25rem;
	margin-bottom: 1rem;
	border: 1px solid transparent;
	border-radius: .25rem;
	position: relative;
	top: 22px;
}
    .news__letter.form__tr .container {
	width: 66% !important;
}
    .categories__list__s .container {
	width: 88%;
}
   .daily__new .container {
	max-width: 72%!important;
}
    .topads {
	padding-bottom: 45px;
}
   .leftads {
	position: fixed;
	left: 59px;
}
  .rightads {
	position: fixed;
	right: 63px;
}
.medium-post-style-1, .post-style-1 {

	display: inline-block!important;
}
	.sg-post.medium-post-style-1 {
	width: 100%;
}
	.medium-post-style-1 .entry-thumbnail {
	width: 100%;
}
	body {
	background: #f2f2f2;
}
	
	.banner__s.d__059i.new_slider .container {
	width: 85%;
} 
    
    .sg-sidebar__theiaStickySidebar #homenews {
	width: 70%;
}
    @media  screen and (min-width:1100px) and (max-width:1500px) {
.global-list.d-flex.newest {
	margin-left:84px !important;
}
        .b__9656.homenewsletterclick {
	position: relative;
	left: 27px !important;
	top: -72px;
	float: right;
	z-index: 9999;
}
        
        .mainclasssliderimg ul li {
	width: 35%;
	display: inline-block;
	margin-right: 10px;
}
}
    .sg-main-content.mb-4 {
	min-height: 400px;
}
    .sg-main-content.mb-4 {
	margin-top: 125px;
}
    .l__contents1 .tr-form #news {
	background: #fff !important;
}
   .tr-form #news {
	background: rgb(233, 227, 254) !important;
}
    .global-list.d-flex {
	margin-left: 47px!important;
}
   .carousel-wrap {
   margin: 90px auto;
   padding: 0 5%;
   width: 80%;
   position: relative;
   }
   .banner__s .col-lg-12 {
   padding: 0px;
   }
   .banner__s {
   margin-top: -31px;
   }
   .sg-menu.menu-style-1 {
   position: relative;
   z-index: 99;
   }
   /* fix blank or flashing items on carousel */
   .owl-carousel .item {
   position: relative;
   z-index: 100; 
   -webkit-backface-visibility: hidden; 
   }
   /* end fix */
   .owl-nav > div {
   margin-top: -26px;
   position: absolute;
   top: 50%;
   color: #cdcbcd;
   }
   .owl-nav i {
   font-size: 52px;
   }
   .owl-nav .owl-prev {
   left: -30px;
   }
   .owl-nav .owl-next {
   right: -30px;
   }
   .owl-nav .owl-prev {
   left: 6px!important;
   }
   .owl-nav > div {
   margin-top: -26px;
   position: absolute;
   top: 50%;
   color: #cdcbcd;
   }
   .owl-nav .owl-next {
   right: 8px!important;
   }
   .add__banners {
   margin-bottom: 28px;
   }
   .daily__news__pro {
   background: #fff;
   }
   .hdaily_s h3 {
   font-size: 16px;
   color: #222;
   font-weight: 500;
   }
   .loop-item-meta_0 {
   background: #EF3C0E;
   display: inline-block;
   color: #fff;
   padding: 0px 8px 2px 8px;
   border-radius: 34px;
   font-size: 12px;
   margin-top: 7px;
   margin-bottom: 9px;
   }
.hdaily_s {
	padding: 15px;
	height: 200px;
}
   .hdaily_s p {
   font-size: 13px;
   }
   .all__heading {
   margin-bottom: 20px;
   margin-top: 37px;
   }
   .all__heading h3 {
   color: #000;
   font-size: 20px;
   }
   .all__heading::before {
   content: "";
   background: #0000004a;
   height: 1px;
   width: 88%;
   display: inline-block;
   float: right;
   position: relative;
   top: 21px;
   }
   .sg-home-section {
   display: none;
   }
   .daily__new {
   margin-bottom: 44px;
   }
   .a__bac__l {
   border-radius: 20px;
   background-color: rgb(255, 255, 255);
   box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
   padding: 80px 0;
   text-align: center;
   }
   .forum__group input {
   background: rgb(233, 227, 254);
   border: 1px solid #0000001c;
   padding: 9px;
   font-size: 15px;
   width: 32%;
   border-radius: 7px;
   margin-bottom: 17px;
   }
   .sub {
   background: #EF3C0E;
   border: none;
   color: #fff;
   padding: 7px 30px 7px 30px;
   border-radius: 7px;
   }
   .a__bac__l h3 {  
   color: #000;
   margin-bottom: 16px;
   }  
   .a__bac__l p {
   text-transform: uppercase;
   letter-spacing: 1px;   
   margin-top: 23px;
   margin-bottom: 23px;
   }
   .list__categories__list li {
   list-style: none;
   }
   .list__categories__list {
   padding: 7px;
   }
   .list__categories__li_sting {
   background: #fff;
   padding: 6px;
   border-radius: 5px;
   }
   .static_09 h3 {
   font-size: 14px;   
   color: #000;
   padding: 10px;
   margin-bottom: 0px;
   }
   .list__categories__list li {
   display: inline-block;
   width: 19.7%;
   padding: 5px;
   }
   .sg-main-content.mb-4 {
   display: none;
   }
   .all__heading h3 {
   color: #000;
   font-size: 20px;
   text-transform: uppercase;
   }
   .hdaily_s h3 {
   font-size: 13px;
   color: #222;
   font-weight: 400;
   line-height: 20px;
   }
   .categories__list__s {
   padding-bottom: 36px;
   padding-top: 16px;
   }
   .static_09 h3 {
   font-size: 14px;
   color: #000;
   padding: 10px;
   margin-bottom: 0px;
   font-weight: 500;
   line-height: 19px;
   }
   .daily__new {
   margin-bottom: 44px;
   margin-top: 62px;
   }
   .all__heading {
   margin-bottom: 33px;
   margin-top: 37px;
   text-align: center;
   }
   .banner__s {
   padding: 13px 26px 23px 26px!important;
   }
   .img__08 img {
   width: 100px;
   height: 100px;
   border-radius: 72%;
   margin-left: auto;
   margin-right: auto;
   }
   .img__08 {
   text-align: center;
   }
   .list__categories__li_sting {
   background: transparent;
   padding: 6px;
   border-radius: 5px;
   }
   .static_09 {
   text-align: center;
   }
   .static_09 h3 {
   font-size: 14px;
   color: #000;
   padding: 10px;
   margin-bottom: 0px;
   font-weight: 500;
   line-height: 19px;
   letter-spacing: 1px;
   }
   .daily_img .img-fluid {
   height: 165px;
   border-radius: 6px 6px 0px 0px;
   }
   .list__categories {
 
   margin-left: auto;
   margin-right: auto;
   }
   .list__categories__li_sting {
   margin-bottom: 18px;
   }
   .exccinte{
   text-align: center;
   }
   .view__all__09 {
   text-align: center;
   }
   .view__all__09 span {
   border: none;
   padding: 5px 26px 7px 26px;
   border-radius: 36px;
   background:rgba(34, 54, 102, 0.98);
   color: #fff;
   font-size: 13px;
   }
.img__08 img {
	width: 150px;
	height: 150px;
	border-radius: 72%;
	margin-left: 11px;
	margin-right: auto;
	padding: 25px;
	border: 1px solid #0003;
	background: #fff;
	margin-top: -201px;
}
	.static_09 {
	text-align: center;
	margin-top: -27px;
	margin-left: 18px;
}
   .daily__news__pro {
   background: #fff;
   border-radius: 6px;
   box-shadow: 0px 0px 20px 6px rgba(107, 83, 254, 0.1);
   }
   .sg-widget.widget-social {
   display: none;
   }
   .tr-form {
   width: 50%!important;
   margin-left: auto;
   margin-right: auto;
   }
   #news {
   background: rgb(233, 227, 254);
     border: 1px solid #989a9f70 !important;
   padding: 9px;
   font-size: 15px;
   width: 74%!important;
   border-radius: 7px;
   margin-bottom: 17px;
   }
   .daily__new .container {
   max-width: 72%;
   }
  .hdaily_s h3 {
	font-size: 17px;
	color: #222;
	font-weight: 400;
	line-height: 23px;
	color: #000 !important;
	height: 124px;
}
   .footer-content .sg-socail li a {
   width: 35px;
   height: 35px;
   line-height: 32px;
   display: block;
   text-align: center;
   border-radius: 100%;
   color: #333;
   font-size: 15px;
   border: 1px solid #3d9be140;
   line-height: 3px !important;
   }   
   .sg-socail {
   margin-left: -127px;
   }   
   .daily_img .img-fluid {
   height: auto;
   border-radius: 6px 6px 0px 0px;
   width: 100%;
   }   
   .daily__news__pro {   
   background: #fff;
   border-radius: 6px;
   box-shadow: 0px 0px 20px 6px rgba(107, 83, 254, 0.1);
   margin-bottom: 26px;
   }
   .second.circle {
   position: relative;
   margin-left: 47px;
   }
   @media  screen and (min-width:1100px) and (max-width:1550px){
   .second.circle {
   position: relative;
   margin-left: 38px;
   }
       .col-md-2asfasf .search-form.d__rtt {
	right: 3px !important;
}
   }
   .sg-sidebar__theiaStickySidebar .widget-title {
   display: none;
   }
   .sidebar__theiaStickySidebar p {
   display: none;
   }
  
   .sg-sidebar__theiaStickySidebar .widget-newsletter {
   border-radius: 17px;
   background-color: transparent;
   box-shadow: none;
   padding: 13px 0;
   text-align: center;
   }
   .sg-sidebar__theiaStickySidebar .tr-form {
   width: 70% !important;
   margin-left: 0px;
   margin-right: auto;
   }
   .banner__sectionss {
   padding-top: 95px;
   }
   .l__contents1 {
   width: 94%;
   padding-top: 57px;
   }
   .s__09d_0.exccinte .item img {
   /* width: 68%; */
   margin-top: 26px;
   }
   .all__heading::before {
   content: "";
   background: transparent!important;
   height: 1px;
   width: 100%;
   display: inline-block;
   float: right;
   position: relative;
   top: 16px;
   }
   .all__heading h3 {
	color: #073C65;
	font-size: 72px;
	text-transform: uppercase;
}
   .hdaily_s h3 a {
   color: #333;
   font-size: 17px;
   font-weight: 600;
   }
   .loop-item-metad_0 {
   margin-top: 28px;
   color: #777;
   font-size: 14px;
   }
   .widget-newsletter.text-center {
   background:url(<?php echo e(static_asset('site/images/back.jpg')); ?>);
   }
   .news__letter .container {
   max-width: 72%;
   }
.widget-newsletter.text-center {
	text-align: center !important;
	color: #fff;
	padding-left: 0px;
}
   .widget-newsletter .widget-title {
   font-weight: 500;
   color: #fff;
   font-size: 27px;
   padding: 8px 0px;
   margin-bottom: 20px;
   text-transform: uppercase;
   background-color: transparent;
   }
   .widget-newsletter .tr-form {
   width: 60%;
   margin-left: auto;
   margin-right: auto;
   }
   #news {
   background: transparent!important;
     border: 1px solid #989a9f70 !important;
   padding: 11px;
   font-size: 15px;
   width: 70%;
   border-radius: 7px;
   margin-bottom: 17px;
   }
   #news .form-control {
   height: 57px;
   border-radius: 4px;
   padding: 6px 20px;
   margin-bottom: 30px;
   border: 1px solid #d8e2e9;
   }
   .widget-newsletter .widget-title {
   font-weight: 600;
   color: #fff;
   font-size: 30px;
   padding: 24px 0px;
   margin-bottom: 20px;
   text-transform: uppercase;
   background-color: transparent;
   }
   .widget-newsletter.text-center {
   background-size: cover;
   }
   .banner__sectionss .widget-newsletter.text-center {
   background: transparent;
   padding-left: 0px;
   }
   .banner__sectionss .sg-sidebar__theiaStickySidebar .tr-form {
   width: 94% !important;
   margin-left: 0px;
   margin-right: auto;
   }
   .banner__sectionss #news {
   background: rgb(233, 227, 254);
  border: 1px solid #989a9f70 !important;
   padding: 9px;
   font-size: 15px;
   width: 70%;
   border-radius: 7px;
   margin-bottom: 17px;
   }
 .second.circle {
	position: relative;
	margin-left: 9px;
	margin-top: -5px;
	top: -6px;
}
   canvas {
   width: 159px;
   }
   .banner__sectionss {
   padding-top: 123px;
   margin-bottom: 53px;
   }
   .daily__new {
   margin-bottom: 44px;
   margin-top: 88px;
   }
   .view__all__09 span {
   border: none;
   padding: 14px 38px 13px 38px;
   border-radius: 10px;
   background:#073c65;
   color: #fff;
   font-size: 13px;
   text-transform: uppercase;
   font-size: 19px;
   margin-top: 42px;
   display: inline-block;
   margin-bottom: 22px;
   cursor: pointer;
   } 
	
	.showless__0 span {
   border: none;
   padding: 14px 38px 13px 38px;
   border-radius: 10px;
   background:#073c65;
   color: #fff;
   font-size: 13px;
   text-transform: uppercase;
   font-size: 19px;
   margin-top: 42px;
   display: inline-block;
   margin-bottom: 22px;
   cursor: pointer;
   }
	

   .banner__s.d__059i .widget-newsletter.text-center {
   background: transparent;
   padding-left: 0px;
   }
   .banner__s.d__059i  .sg-sidebar__theiaStickySidebar .tr-form {
   width: 96% !important;
   margin-left: 0px;
   margin-right: auto;
   }
   .banner__s.d__059i {
   padding-top: 143px !important;
   padding-bottom: 75px !important;
   }
    
    .cont__yr {
	padding-left: 16px;
	margin-right: 14px;
}
    
    .cont__yr li {
	font-size: 14px;
	margin-bottom: 4px;
}
    .cont__yr {
	margin-bottom: 32px;
}
    .s_dd {
	margin-top: -34px;
}
    
    .l__contents1 p {
	font-size: 14px;
	color: #000;
}
    .l__contents1 i {
	font-size: 13px;
}
    
    .banners2 .img__banners img {
	width: 85%;
}
    
    .banners2 .l__contents1 {
	margin-top: 74px;
}
    
    .banners3 .l__contents1 {
	margin-top: 78px;
	width: 76%;
}
    
    .banners4 .l__contents1 {
	margin-top: 27px;
	width: 77%;
}
    
     .banners4 .img__banners img {
	width: 117% !important;
	max-width: 121%;
	margin-left: -72px;
}
    
    .banners1 .img__banners img {
	max-width: 114%;
	width: 123% !important;
	margin-left: -31px;
}
    
#home-carouselgfgfgfg .btn-success {
	color: #fff;
	background-color:#073c65;
	border-color: #073c65;
	padding: 8px 27px 9px 27px;
	float: left;
	margin-right: 27px;
	margin-top: 24px;
	border-radius: 6px;
}
    .banner__s.d__059i {
	padding-top: 128px !important;
	padding-bottom: 0px !important;
        height:101vh;
}
 .item.banners1 {
	padding-top: 66px;
}   
    .widget-newsletter.text-center {
	
	background-size: 100% 100% !important;
}
	.mainclasssliderimg ul li {
	width: 35%;
	display: inline-block;
}
	.mainclasssliderimg ul {
	padding: 0px;
	margin-top: 35px;
}
	.banners3 img {
	width: 85%!important;
}
	
.s__09d_0.exccinte .item img {
	width: 100% !important;  
	margin-top: 26px;
	border-radius: 11px;
	box-shadow: 0 0 6px 5px #0000000a;
}   
  
	.showless__0 {
	text-align: center;
	
}
	.showless__0 {
	display: none;
}
    @media  screen and (min-width:320px) and (max-width:767px){
        .sg-sidebar__theiaStickySidebar #homenews {
	width: 59%!important;
}

    .loop-item-metad_0 {
	margin-top: 46px;
	color: #777;
	font-size: 14px;
}
        .global-list.d-flex {
	margin-left:-18px !important;
}
    }
      .modal-dialog {
	max-width: 558px;
	margin: 10.75rem auto;
}
    .modal-header {
	display: -ms-flexbox;
	display: block;
	-ms-flex-align: start;
	align-items: flex-start;
	-ms-flex-pack: justify;
	justify-content: space-between;
	padding:0px!important;
	border-bottom: none!important;
	border-top-left-radius: .3rem;
	border-top-right-radius: .3rem;
}
    .modal-header .close {
	padding: 1rem 1rem;
	margin: -1rem -1rem -1rem auto;
	position: relative;
	top: -78px !important;
}
    .modal-header h3 {
	color: #000;
	font-size: 22px;
	
}
    .modal-header p {
	font-size: 15px !important;
	color: #000;
}
	.submit_button input {
	width: 100%;
	border-radius: 3px;
	background: #073c65;
	padding-bottom: 9px;
	margin-top: 25px;
}
    .modal-content {
	padding: 18px;
}
    .modal-body {
	margin-top: -13px;
}
    .radio {
	margin-bottom: 10px;
        color:#000;
}
    .radio input {
	margin-right: 10px;
	font-size: 13px!mportant;
}
    .checkbox-inline input {
	margin-right: 10px;
}
    .checkbox-inline{
        color:#000;
    }
   .submit_button input {
	background: #073c65;
	border: #073c65;
	color: #fff;
	border-radius: 10px;
	padding: 4px 20px;
	margin-top: 7px;
}
    .submit_button {
	text-align: center;
}
    .new_popupbutton {
/*	display: none !important;*/
     opacity:0;   
}
      .banner__s.d__059i.new_slider .banners4 .img__banners img {
	width: 100% !important;
	max-width: 121%;
	margin-left: -72px;
	margin-top: 59px;
}
    @media  screen and (min-width:1100px) and (max-width:1450px){
    .banner__s.d__059i.new_slider .banners3 img {
	width: 90% !important;
	max-width: 114%;
}
        .loop-item-metad_0 {
	margin-top: 37px;
	color: #777;
	font-size: 14px;
}
   .banner__s.d__059i.new_slider .banners2 .img__banners img {
	width:90% !important;
	max-width: 114%;
	margin-left: -15px;
}
       .banner__s.d__059i.new_slider .banners2 .l__contents1 {
	margin-top: 37px;
}
       .banner__s.d__059i.new_slider .banners4 .img__banners img {
	width: 100% !important;
	max-width: 121%;
	margin-left: -72px;
	margin-top: 59px;
}
        .cont__yr {
	padding-left: 20px!important;
	margin-right: 14px;
}
    }
	
	
	
	
    canvas{
        height:151px!important;
        width:151px!important;
    }
	
	
	@media  screen and (min-width:320px) and (max-width:767px) {
		#home-carouselgfgfgfg .btn-success {
    color: #fff;
    background-color: #073c65;
    border-color: #073c65;
    padding: 4px 18px 4px 18px;
    float: left;
    margin-right: 0px;
    margin-top: 24px;
    border-radius: 6px;
    margin-bottom: 55px;
    margin-left: 26px!important;
}
        .l__contents1 p {
    font-size: 12px;
    color: #333;
    line-height: 20px;
    margin-left: 42px!important;
}
		.banner__s.d__059i.new_slider .container {
	width: 100%;
	max-width: 100%;
}
		.newhead_new h1 {
	margin-bottom: 41px !important;
}
.l__contents1 {
	width: 94%;
	padding-top: 10px;
}
		.banner__s.d__059i {
	padding-top: 108px !important;
	padding-bottom: 0px !important;
	height: auto;
}
		.l__contents1 p {
	font-size: 12px;
	color: #333;
	line-height: 20px;
}
		#home-carouselgfgfgfg .btn-success {
	color: #fff;
	background-color: #073c65;
	border-color: #073c65;
	padding: 4px 18px 4px 18px;
	float: left;
	margin-right: 27px;
	margin-top: 24px;
	border-radius: 6px;
}
		.daily__new .container {
	max-width: 92% !important;
}
		.categories__list__s .container {
	width: 100%;
	max-width: 100%;
}
		.img__08 img {
	width: 150px;
	height: 150px;
	border-radius: 72%;
	margin-left: -8px;
	margin-right: auto;
	padding: 25px;
	border: 1px solid #0003;
	background: #fff;
	margin-top: -169px;
}
		.footer.footer-style-1 .play_buttons ul li {
	width: auto!important;
	margin-right: 0px;
}
		.daily__new {
	margin-bottom: 0px;
	margin-top: 88px;
}
		.mainclasssliderimg ul li {
	width: 46%;
	display: inline-block;
	margin-left: 0px;
	margin-top: -48px;
}
		.banners4 {
	margin-bottom: 24px;
}
		.add__banners .container {
	width: 100%;
	max-width: 100%;
	padding: 0px;
}
		.b__9656.homenewsletterclick {
	position: relative;
	left: 11px !important;
	top: -74px;
	float: right;
	z-index: 9999;
	height: 42px;
}
		.b__9656 {
	background: #ef3a0b !important;
	border: none;
	color: #fff !important;
	padding: 7px 15px 7px 15px !important;
	border-radius: 7px !important;
}
		.paragraph li {
	font-size: 13px;
	line-height: 20px;
	margin-bottom: 13px;
}
.static_09 {
	text-align: center;
	margin-top: -27px;
	margin-left: 0px;
}
		.static_09 h3 {
	font-size: 14px;
	color: #000;
	padding: 2px;
	margin-bottom: 0px;
	font-weight: 500;
	line-height: 19px;
	letter-spacing: 1px;
}
		.sg-socail {  
	margin-left: -87px;
	margin-top: 11px;
	margin-bottom: 55px !important;
}
	}
	
h3.exclusiveintheading {
    width: 100%;
    text-align: center;
    font-size: 72px;
    color: #073C65 !important;
    margin-bottom: -13px;
    margin-top: 33px;
}
    .s__09d_0.exccinte 
 h3.exclusiveintheading {
    margin-bottom: 18px!important;
}
  .s__09d_0.exccinte.new_exccinte_2 {
    padding-bottom: 20px!important;
}
</style>
<?php
$blockPosts = $posts->take(4);
?>
<!--
   <section class="banner__s">
      <div class="row">
         <div class="col-lg-12">
            <div id="home-carouselgfgfgfg" class=" ">
               <div class="owl-carousel">
                  <?php $__currentLoopData = $slider1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postslider1s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="item">
   				   <a href="<?php echo e($postslider1s->url); ?>">
   					<?php if(isFileExist(@$postslider1s->adImage, $result = @$postslider1s->adImage->big_image)): ?>
   					<img src="<?php echo e(basePath($postslider1s->adImage)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($postslider1s->adImage)); ?>/<?php echo e($result); ?>">
   					<?php else: ?>
   					<img src="<?php echo e(static_asset('default-image/default-100x100.png')); ?> "  >
   					<?php endif; ?>	
   				  </a>				
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
         
      </div>
   </section>
   -->
<section class="banner__s d__059i new_slider">
<div class="leftads">     
				<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($ads_AdLocations->unique_name == 'home_page_left'): ?>
						<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
						<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">   
								<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">	
							</a>	
						<?php endif; ?>  
   
						<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>   
							<?php echo e($ads_AdLocations->ad->ad_code); ?>	
						<?php endif; ?>   
   
						<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>   
							<div class="textads">  
								<?php echo e($ads_AdLocations->ad->ad_text); ?>

							</div>	  
						<?php endif; ?>   
					<?php endif; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
			</div>   
   
     
            <div class="rightads">
				<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($ads_AdLocations->unique_name == 'home_page_right'): ?>
						<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
						<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
								<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">	
							</a>
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
							<?php echo e($ads_AdLocations->ad->ad_code); ?>	
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
							<div class="textads">
								<?php echo e($ads_AdLocations->ad->ad_text); ?>

							</div>	
						<?php endif; ?>
					<?php endif; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>

   <div class="container">
   <div class="topads">
			
            <?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($ads_AdLocations->unique_name == 'home_page_top'): ?>
                    <?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
                        <a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
                            <img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">	
                        </a>
                    <?php endif; ?>

                    <?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
                        <?php echo e($ads_AdLocations->ad->ad_url); ?>	
                    <?php endif; ?>

                    <?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
                        <div class="textads">
                            <?php echo e($ads_AdLocations->ad->ad_text); ?>

                        </div>	
                    <?php endif; ?>
                <?php endif; ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


      <div class="row">
         <div class="col-lg-12">
            <div id="home-carouselgfgfgfg" class="carousel-zoom">
               <div class="owl-carousel">
                   <?php 
                    $i=0;
                   ?>

               <?php $__currentLoopData = $slider1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postslider1s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php 
                    $i++;
                   ?>
                  <div class="item banners<?php echo $i ?>">
                     <div class="row">
                        <div class="col-md-6">
                           <div class="l__contents1 newhead_new">
                              <h1 style="color: #ef3a0b;
                                 font-size: 60px;
                                 margin-bottom: 50px;"><?php echo e($postslider1s->title); ?> </h1>

<!-- <?php echo e($postslider1s->content); ?> -->
                            <?php echo @$postslider1s->content; ?>

                                  <!-- <?php if($i == 4): ?>
                                       <div class="s_dd">
                         <ul class="cont__yr">
                               <li>PharmaShots Newswire is trusted news distribution solution curated dedicatedly for Life Science industry</li>
                                <li>Authentic news, reaching to the targeted audience at a very cost-effective price
                                    </li>  <li>Team of experienced life sciences professionals
                                    </li> <li>We understand your business and provide the custom press release writing services
                                    </li><li>More than three years of experience in delivering curated, customized news to our readers 
                                    </li> <li>Reach us for PharmaShots Newswire and custom PR writing service</li>
                                     </ul>    
                                     <i>Grab 51% discount today!
                                    </i>
                               </div>
                                 <?php elseif($i == 2): ?>
							     <p>PharmaShots Bespoke service will provide you</p>
                                 <ul class="cont__yr">
                               <li>Exclusive analysis of biotech, pharma, and the life sciences</li>
                                <li>Inside intelligence on the regulatory organizations (FDA, EMA, NIH)</li>    
                                <li>Clinical trial analysis and key updates</li> 
                                     <li>Coverage from Major congresses</li>
                                <li>Profiles of key players trending, scientific analysis</li>  
                                     <li>KOL/ industry expert interviews</li>
                               </ul>
							 
                                 <?php elseif($i == 3): ?>
                                 <p>Introducing FREE PharmaShots News App – News On the go</p>
                                <ul class="cont__yr">
                               <li>A one-stop app with the key Life sciences news available at one swipe
</li>
                                <li>PharmaShots provides real-time summarized News in 3 shots
</li>    
                                <li>From pharma, biotech, MedTech, digital health, and life sciences Industry </li> 
                                     <li>Readable in 60 seconds
</li>
                                
                               </ul>
                               <i>Download the PharmaShots App now!</i>
                                 <?php elseif($i == 1): ?>
                                <ul class="cont__yr">
                               <li>Real-time summarized News in 3 shots </li>
                               <li>From Pharma, Biotech, Med-Tech, Digital Health, and Life Sciences Industry</li>
                               <li>Readable in 60 seconds</li>
                          
                               </ul>
							   
                                 <?php endif; ?> -->


                                    <!-- <?php echo e($postslider1s->content); ?> -->
                              <div class="sg-sidebar__theiaStickySidebar">
                                  <?php if($postslider1s->button_type == 'Newsletter'): ?>
                                        <!-- <div class="tr-form homenewsletter">
                                            <label for="news" class="d-none">Newsletter</label>
                                            <input name="email" id="homenews" type="email" class="form-control" placeholder="<?php echo e(__('email_address')); ?>" required>
                                            <button class="b__9656 homenewsletterclick">Subscribe Now</button>
                                            <div class="errorclass"></div>
                                        </div> -->
                                        
                                        <div class="tr-form homenewsletter">
                                            <label for="news" class="d-none">Newsletter</label>
                                            <input name="email" id="homenews" type="email" class="form-control" placeholder="<?php echo e(__('email_address')); ?>" required>
                                            <button class="b__9656 homenewsletterclick">Subscribe Now</button>
                                            <div class="errorclass"></div>
                                        </div>
								    <?php elseif($postslider1s->button_type == 'MobileApps'): ?>
                                        <div class="mainclasssliderimg">
                                            <ul>
											<li><a href="https://play.google.com/store/apps/details?id=com.pharmashots"> <img src="<?php echo e(static_asset('site/images/')); ?>/gp.png"></a></li>
											<li><a href="https://apps.apple.com/in/app/pharma-shots/id1526497705\"> <img src="<?php echo e(static_asset('site/images/')); ?>/as.png"></a></li>
                                                <li class="new_popupbutton"><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button></li>
											
											</ul>
                                         </div>
                                    <?php else: ?>
                                        <?php if($postslider1s->url1 && $postslider1s->content1): ?>
                                        <div class="mainclasssliderimg">
                                             <a href="<?php echo e($postslider1s->url1); ?>" class="btn btn-success "><?php echo e($postslider1s->content1); ?></a>
                                         </div>

                                        <?php endif; ?>

                                        <?php if($postslider1s->url2 && $postslider1s->content2): ?>
                                        <div class="mainclasssliderimg">
                                            <a href="<?php echo e($postslider1s->url2); ?>" class="btn btn-success "><?php echo e($postslider1s->content2); ?></a>
                                         </div>
                                        <?php endif; ?>

                                   <?php endif; ?>
                                 
                              </div>
                           </div>  
                        </div>
                        <div class="col-md-6">
                           <div class="img__banners">  
                             
                              <?php if(isFileExist(@$postslider1s->adImage, $result = @$postslider1s->adImage->original_image)): ?>
                                <img src="<?php echo e(basePath($postslider1s->adImage)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($postslider1s->adImage)); ?>/<?php echo e($result); ?>">
                                <?php else: ?>
                                <img src="<?php echo e(static_asset('default-image/default-100x100.png')); ?> "  >
                                <?php endif; ?>	
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               

               </div>
            </div>
         </div>
      </div>
   </div>
</section>

<?php if(count($interviewsAds) > 0): ?>
<div class="add__banners"> 
      	 
   <div class="container"> 
      <div class="s__09d_0 exccinte new_exccinte_2">
         <?php $__currentLoopData = $interviewsAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
         <?php 
            // dd($interviews->ad) 
            ?>
         <div class="item">
            <?php if(count($interviewsAds) > 0): ?>
                <h3 class="exclusiveintheading">COMPANY OF THE MONTH</h3>
            <?php endif; ?>
            <?php if(isFileExist(@$interviews->ad->adImage, $result = @$interviews->ad->adImage->original_image)): ?>
               <a href="<?php echo e($interviews->ad->ad_url); ?>">
                   <img src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>">
                </a>
            <?php else: ?>
            <img src="<?php echo e(static_asset('default-image/default-100x100.png')); ?> "  >
            <?php endif; ?>					
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</div>

<?php endif; ?>



<?php if(count($interviewsAdsMobile) > 0): ?>
<div class="add__banners">    
       
   <div class="container"> 
      <div class="s__09d_0 exccinte new_exccinte">
         <?php $__currentLoopData = $interviewsAdsMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php 
            // dd($interviews->ad) 
            ?>
         <div class="mbile_viewimg">
                <?php if(count($interviewsAdsMobile) > 0): ?>
                    <h3 class="exclusiveintheading">COMPANY OF THE MONTH</h3>
                <?php endif; ?>	
            <?php if(isFileExist(@$interviews->ad->adImage, $result = @$interviews->ad->adImage->original_image)): ?>
               <a href="<?php echo e($interviews->ad->ad_url); ?>">
                   <img src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>">
                </a>
            <?php else: ?>
            <img src="<?php echo e(static_asset('default-image/default-100x100.png')); ?> "  >
            <?php endif; ?>					
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</div>

<?php endif; ?>

<?php if(count($interviewsAds2) > 0 || count($interviewsAdsMobile2) > 0): ?>
    <h3 class="exclusiveintheading">EXCLUSIVE INTERVIEW</h3>
<?php endif; ?>

<?php if(count($interviewsAds2) > 0): ?>
<div class="add__banners">    	 
   <div class="container"> 
      <div class="s__09d_0 exccinte new_excintte23">
         <?php $__currentLoopData = $interviewsAds2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>       
         <div class="item">
            <?php if(isFileExist(@$interviews->ad->adImage, $result = @$interviews->ad->adImage->original_image)): ?>
               <a href="<?php echo e($interviews->ad->ad_url); ?>">
                   <img src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>">
                </a>
            <?php else: ?>
            <img src="<?php echo e(static_asset('default-image/default-100x100.png')); ?> "  >
            <?php endif; ?>					
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</div>

<?php endif; ?>


<?php if(count($interviewsAdsMobile2) > 0): ?>
<div class="add__banners">    	 
   <div class="container"> 
      <div class="s__09d_0 exccinte">
         <?php $__currentLoopData = $interviewsAdsMobile2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interviews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php 
            // dd($interviews->ad) 
            ?>
         <div class="mbile_viewimg">
            <?php if(isFileExist(@$interviews->ad->adImage, $result = @$interviews->ad->adImage->original_image)): ?>
               <a href="<?php echo e($interviews->ad->ad_url); ?>">
                   <img src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($interviews->ad->adImage)); ?>/<?php echo e($result); ?>">
                </a>
            <?php else: ?>
            <img src="<?php echo e(static_asset('default-image/default-100x100.png')); ?> "  >
            <?php endif; ?>					
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
   </div>
</div>

<?php endif; ?>
<section class="daily__new">
   <div class="container">
      <div class="all__heading" style="margin-bottom: 56px;">
         <h3 style="">Daily News</h3>
<!--         <p style="padding-bottom: 26px;">Lorem Ipsum is simply dummy text of the printing and typesetting</p>-->
      </div>
      <div class="row">
         <?php $__currentLoopData = $dailynews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-4">
            <div class="daily__news__pro">
               <div class="daily_img">				  
                  <?php if(isFileExist(@$post->image, @$post->image->original_image)): ?>
                  <img class="img-fluid"
                     src="<?php echo e(basePath(@$post->image)); ?>/<?php echo e($post->image->original_image); ?>"
                     data-original="<?php echo e(basePath(@$post->image)); ?>/<?php echo e($post->image->original_image); ?>"
                     alt="<?php echo $post->alt_tag; ?>">
                  <?php else: ?>
                  <img src="<?php echo e(static_asset('default-image/default-358x215.png')); ?> "
                     class="img-fluid" alt="<?php echo $post->alt_tag; ?>">
                  <?php endif; ?>
               </div>
               <div class="hdaily_s">
                  <h3><a href="<?php echo e(route('article.detail', ['slug' => $post->slug, 'id' => $post->id])); ?>"><?php echo \Illuminate\Support\Str::limit($post->title,130); ?></a></h3>
                  <div class="loop-item-metad_0">
                     <?php echo e(Carbon\Carbon::parse($post->updated_at)->format('M d, Y')); ?>

                  </div>
               </div>
            </div>  
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
	   
	  
	   
	   
      <p class="view__all__09"><span><a style="color: #fff;" href="<?php echo e(url('/newshome')); ?>">Show More</a></span></p>
      	
   </div>
</section>







<!--
<section class="play___store_098">
<div class="container">
	
<div class="row">
	
	<div class="col-md-5">
	
	<div class="app__mobile__img">
		<img src="<?php echo e(static_asset('pmobile.png')); ?> "  >
		</div>
	</div>
	
	<div class="col-md-7">
	<div class="new__con__app6755">
		
		<p>Download Pharmashots App</p>
		<h3>Why scroll down the long news articles when we you can get the same information in 60-word shorts?</h3>
		<div class="play__stor__button">
		<ul>
			<li><a href="https://play.google.com/store/apps/details?id=com.pharmashots" target="_blank"><img src="<?php echo e(static_asset('play1.svg')); ?> "></a></li>
			<li><a href="https://apps.apple.com/in/app/pharma-shots/id1526497705/" target="_blank"><img src="<?php echo e(static_asset('play2.svg')); ?> "></a></li>
			
			</ul>
		</div>
		</div>
	</div>
	</div>
	
	</div>

</section>
-->


<section class="news__letter form__tr newsleehomepage"   id="newsletters">
   <div class="container">
	   
	     <h3 class="widget-title d__999">Join the PharmaShots family of <br/> 12000+ subscribers</h3>
	   
      <div class="sg-sidebar theiaStickySidebar row">
		  <div class="col-md-12">
         <div class="sg-widget news__0f1245">
   
                <div class="widget-newsletter text-center">
                    <?php echo $__env->make('site.partials.right_sidebar_widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    

                </div>
            </div>
			  
			  </div>
		  
		   
		  
		  
      </div>
   </div>
</section>


<?php  
if (count($youtubevideos) > 0) { ?>
<section class="video_sections" style="margin-top: 48px;">
   <div class="container">
      <div class="all__heading" style="margin-bottom: 56px;">
        <h3 style="">Video News</h3>
      </div>
      <div class="row">
         <?php $__currentLoopData = $youtubevideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $youtubevideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php 
            if (count($youtubevideos) > 1) {
                $class = '6';
            }else{
                $class = "12";
            }
         ?>
         <div class="col-md-<?php echo e($class); ?>">
            <div class="video_sections__pro">
                <iframe width="100%" height="500" src="<?php echo e($youtubevideo->embed_video); ?>?controls=0"></iframe>
            </div>  
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>      	
   </div>
</section>

<?php } ?>


<section class="categories__list__s" style="margin-bottom: 61px;">
   <div class="container">
      <div class="all__heading" style="margin-bottom: 66px;">
         <h3 style="
            display: inline-block;
            position: relative; ">Categories</h3>
<!--         <p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>-->
      </div>
      <div class="list__categories">
         <div class="row">
            <ul class="list__categories__list">
               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li>
                  <div class="list__categories__li_sting">
                     <a href="<?php echo e(url('category')); ?>/<?php echo e($category->slug); ?> ">
                        <div class="img__08 ">
                           <div class="second circle"></div>
                           <?php if(isFileExist(@$category->image, $result = @$category->image->thumbnail)): ?>
                           <img class="" src="<?php echo e(basePath($category->image)); ?>/<?php echo e($result); ?>" data-src="<?php echo e(basePath($category->image)); ?>/<?php echo e($result); ?>">
                           <?php else: ?>
                           <img src="<?php echo e(static_asset('default-100x100.png')); ?> "  >
                           <?php endif; ?>		
                        </div>
                        <div class="static_09">
                           <h3><?php echo e($category->category_name); ?> </h3>
                        </div>
                     </a>
                  </div>
               </li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
         </div>
      </div>
   </div>
</section>
<div class="container">
<!--  <h2>Modal Example</h2>-->
  <!-- Trigger the modal with a button -->
  

  <!-- Modal -->
  
<div class="modal fade" id="newsletterpopup" role="dialog" aria-modal="true" >
        <div class="modal-dialog">
        
        <div class="modal-content">
            <div class="modal-header">
                <h3> Liked our insights or summarized news?</h3>
                <p>Subscribe to our Daily/Weekly newsletter</p>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('subscribe1.newsletter')); ?>" class="tr-form" method="POST">
            <?php echo csrf_field(); ?>

            <div class="radio">
                <label> First Name</label>
                <input type="text" class="first_name form-control" required id="first_name" placeholder="First Name"  value="" name="first_name">
            </div>

            <div class="radio">
                <label> Last Name </label>
                <input type="text" class="last_name form-control" required id="last_name"  placeholder="Last Name" value="" name="last_name">
            </div>
            <div class="radio">
                <label>
                    <input type="checkbox" class="nessleeter" id="daily"  value="daily" name="newsletter_type[]" checked>
                    Daily Newsletter
                </label>
            </div>
            <div class="radio">
            <label>
                <input type="checkbox" class="nessleeter"  id="weekly"    value="weekly" name="newsletter_type[]">
                Weekly Newsletter
            </label>
                
            </div>
                        <label class="checkbox-inline">
            <input type="checkbox" required value="">I agree to the privacy policy and terms.(<a href="<?php echo e(url('/')); ?>/app-privacy-policy">Link</a>)
            </label>
                    <div class="submit_button">

            <input name="email" id="popupemail" type="hidden" class="form-control" placeholder="<?php echo e(__('email_address')); ?>" required>
            <input type="submit" value="Subscribe">

        
        </div>
            </form>
            </div>

        </div>
        
        </div>
    </div>


          
<script>
  
  //   $(document).ready(function() {
  //       $('#myModal').modal('show');
  //   });
  </script>
  
</div>

<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("headdf");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}

</script>


   
<style>
    @media  screen and (min-width:1000px) and (max-width:1450px){
        .news__lettersd .sg-sidebar.theiaStickySidebar {
	width: 97%;
	margin-right: 17px;
}
    }
.widget-newsletter {
	border-radius: 20px;
	background-color: rgb(255, 255, 255);
	box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
	padding: 14px 0!important;
	text-align: center;
}
	.widget-title {
	font-weight: 500;
	color: #000;
	font-size: 27px;
	padding: 8px 20px;
	margin-bottom: 20px;
	text-transform: uppercase;
	background-color: transparent;
}
	
	.news__lettersd {
	float: left;
	width: 100%;
	background: #f4f8fb;
}
	
#news {
	background: rgb(233, 227, 254);
	border: 1px solid #0000001c;
	padding: 9px;
	font-size: 15px;
	width: 70%;
	border-radius: 7px;
	margin-bottom: 17px;
}
	
	.b__9656 {
	background:#073c65!important;
  
	border: none;
	color: #fff!important;
	padding: 7px 30px 7px 30px!important;
	border-radius: 7px!important;
}
	
	.tr-form {
	width: 44%;
	margin-left: auto;   
	margin-right: auto;
}   
	   
		.news__lettersd .container {  
	width: 68%;  
}
	   
	.tr-form {
	width: 60%;      
	margin-left: auto;
	margin-right: auto;     
}
    .section_app4 {   
	float: left;          
	width: 100%;
	padding-top: 0px;
	padding-bottom: 40px;      
}      
 .owl-dots button i {
        position: absolute; 
        z-index: 9999;   
        width: 100%;    
        height: 100%;
    }      
	         
.daily_img {
	height: 169px!important;
	overflow: hidden;      
	display: table-cell!important;
	text-align: center;
	vertical-align: middle;
	width: 100%;   
	height: 170px!important;
	background-color: transparent;
}  
	.hdaily_s h3 a {
	color: #333;   
	font-size: 16px!important;
	font-weight: 600;
}
	  
.leftads img {
	width: 83%;
	margin-top: 27px;  
}
	   
	.rightads {
	margin-top: 27px;   
}  
	.rightads img {
	width: 83%;
	float: right;  
}
	.banner__s.d__059i {
	padding-top: 128px !important;
	padding-bottom: 0px !important;
	height: auto;
}  
	.topads img {
	width: 100%;
	margin-top: 26px;
}
	   
	.banner__s.d__059i.new_slider .container {
	width: 71% !important;
}
	
	.play__stor__button li {
	line-height: ;
	list-style: none;
	float: left;
	width: 30%;
	margin-right: 20px;
}
.play__stor__button ul {
	float: left;
	width: 100%;
	padding-left: 0px;
	margin-top: 31px;
}

.new__con__app6755 {
	padding: 87px;
}
.new__con__app6755 h3 {
	color: #000;
	width: 76%;
	line-height: 33px;
	margin-top: 33px;
}
            .new__con__app6755 p {
	color: #FF5038;
	letter-spacing: 1px;
}
.app__mobile__img img {
	width: 93%;
}

.play___store_098 {  
	padding-bottom: 78px;
}
	.news__letter.form__tr .container {
	width: 70% !important;
}
	
	.widget-title.d__999 {
	text-align: center;
	color: #073C65;
	font-size: 50px;
	font-weight: 600;
	margin-bottom: 58px;
}
	
	.widget-newsletter {

	padding: 29px 0;
	
}
	
	.tr-form {
	width: 87% !important;
	margin-left: auto;
	margin-right: auto;
}
	
.news__letter.form__tr .widget-newsletter.text-center {
	padding-top: 13px !important;
	padding-bottom: 47px !important;
}
	
	.tr-form.homenewsletter1 .b__9656 {
	border: none;
	color: #fff !important;
	padding: 11px 17px 11px 17px !important;
	border-radius: 7px !important;
}
	
	#homenews1 {
	width: 66%;
}
	
	.newslettercheckboc {
	margin-top: -20px;
}
	
	.sg-widget.news__0f1245 .widget-title {
	margin-bottom: -9px;
}
	
	.sg-widget.news__0f1245 .b__9656 {
	background: #ef3a0b !important;
	
}
	
	.widget-newsletter.text-center h6 {
	font-size: 21px;
	text-align: left;
	
	padding-left: 34px;
}
</style>
   
<?php /**PATH /var/www/html/resources/views/site/partials/home/primary/style_3.blade.php ENDPATH**/ ?>