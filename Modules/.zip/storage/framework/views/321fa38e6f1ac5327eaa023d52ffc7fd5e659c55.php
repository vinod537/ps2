<style>
    @media  screen and (min-width:1100px) and (max-width:1500px){
        .global-list.d-flex.newest {
	margin-left: -146px!important;
}
        

    }
     .entry-meta.mb-2.datesdsf .global-list li {
	margin-left: 229px;
	margin-top: -16px;
}
   .entry-meta.mb-2 {
	margin-bottom: 16px!important;
	margin-top: -3px!important;
	margin-left: 20px;
}
  .sg-section.d__showinnf_-0999  .form-group {
    display: none;
}
.widget-newsletter {
	border-radius: 20px;
    background-image:url('../public/site/images/subscribe.png');
/*	background-color: rgb(255, 255, 255);*/
	box-shadow: 0px 0px 94px 6px rgba(107, 83, 254, 0.1);
	padding: 80px 0;
	text-align: center;
}

	.entry-thumbnail {
	margin-bottom: 24px;
}
	
	.post-style-2 .entry-content {
	position: relative;
	bottom: 0;
	left: 0;
	width: 100%;
	color: #fff;
	padding: 20px;
}
	
#myHeader .sg-socail li:nth-child(3) {
 display:none;
}
  #myHeader  .sg-socail li:nth-child(4) {
 display:none;
}
   #myHeader .sg-socail li:nth-child(5) {
 display:none;
}
	
	.post-style-2 .entry-content {
	position: relative!important;
	bottom: 0;
	left: 0;
	width: 100%;
	color: #fff;
	padding: 20px;
}
	
	.post-style-2 .entry-content, .sg-post .entry-content.absolute {
	position: absolute;
	bottom: 0;
	left: 0;
	padding: 20px;
	z-index: 1;
	color: #fff;
	background: none!important;

	width: 100%!important;
}
	.post-style-2 .entry-title a {
	color: #000!important;
}
	
	.s__088f .entry-thumbnail img {
	height: 208px;
}
	
	.s__088f  .sg-post .category ul li a, a.read-more {
	color: #fff;
	display: block;
	padding: 0px 16px;
	background-color: #6C6665;
	border-radius: 39px;
	color: #fff !important;
	font-size: 10px;
	letter-spacing: 1px;
}
/*
	.sg-sidebar.theiaStickySidebar {
	display: none;
}
*/
	
	.views__relaed .container {
	width: 66%;
}
	
	.views__relaed {
	background: #f4f8fb;
	padding-top: 53px;
}
	
	.post-style-2:hover .entry-content, .sg-post:hover .entry-content.absolute {
	padding-top: 20px !important;
	background: transparent !important;
	background: transparent !important;
	background: transparent !important;
	background: transparent !important;
}
	
	.views__relaed .sg-post {

	box-shadow: 8px 14px 38px rgba(39,44,49,.06),1px 3px 8px rgba(39,44,49,.03) !important;
}
	.post-style-2 .entry-title a {
	color: #000 !important;
	font-size: 12px;
}

	.views__relaed .section-title {
	margin-bottom: 20px;
	border-bottom: none;
	/* font-size: 32px !important; */
}
	
		.views__relaed .section-title h1 {
	font-size: 20px;
	color: #242329;
	font-weight: 500;
	text-transform: capitalize;
	text-decoration: underline;
}
	.sg-section .d__showinnf_-0999 h1 {
	text-decoration: underline;
	margin-top: 33px;
	display: inline-block;
}
	.texttt .owl-item {
	padding: 18px;
}
	.owl-nav {
	display: block!important;
}
	
	
/* fix blank or flashing items on carousel */
.owl-carousel .item {
  position: relative;
  z-index: 100; 
  -webkit-backface-visibility: hidden; 
}

/* end fix */
.owl-nav > div {
  margin-top: -26px;
  position: absolute;
  top: 50%;
  color: #cdcbcd;
}

.owl-nav i {
  font-size: 52px;
}

.owl-nav .owl-prev {
  left: -30px;
}

.owl-nav .owl-next {
  right: -30px;
}
.owl-nav .owl-prev {
	left: 6px!important;
}
	.owl-nav > div {
	margin-top: -26px;
	position: absolute;
	top: 50%;
	color: #cdcbcd;
}
	.owl-nav .owl-next {
	right: 8px!important;
}
	.add__banners {
	margin-bottom: 28px;
}
	
	.daily__news__pro {
	background: #fff;
}
	
	.hdaily_s h3 {
	font-size: 16px;
	color: #222;
	font-weight: 500;
}
	
.loop-item-meta_0 {
	background: #EF3C0E;
	display: inline-block;
	color: #fff;
	padding: 0px 8px 2px 8px;
	border-radius: 34px;
	font-size: 12px;
	margin-top: 7px;
	margin-bottom: 9px;
}
	
	.hdaily_s {
	padding: 15px;
}
	.hdaily_s p {
	font-size: 13px;
}

	
	.owl-nav .owl-prev {
	left: -31px !important;
}
	.owl-nav .owl-next {
	right: -26px !important;
}
	.widget-title {

	color: #fff!important;

}
    .widget-newsletter.text-center p {
	color: #fff;
}
	.sg-widget.widget-social .widget-title {
	display: none;
}
	
	.news__lettersd .sg-widget.widget-social {
	display: none;
}
	
	.news__lettersd__top .sg-widget.news__0f1245 {
	display: none;
}
	
	.news__lettersd__top .container {
	width: 100%;
	max-width: 100%;
}
	
	.widget-social ul {

	box-shadow: none!important;
}
	.list___129 {
	display: none !important;
}
	
	.widget-social ul {
	padding: 0px;
	
}
	
	.sg-sidebar.theiaStickySidebar .s__00__0 {
	float: left;
}
	.c__set__0d {
	float: left;
}
	
	.sg-sidebar.theiaStickySidebar .global-list {
	padding: 0px !important;
	margin-left: 24px;
}
	.sg-sidebar.theiaStickySidebar {
	float: right;
}
	
.news__lettersd__top {
	position: fixed;
	top: 0px;
	background: #fff;
	z-index: 999;
	box-shadow: 0 0 3px 2px #00000017;
	width: 100%;
	padding-top: 13px;
	height: 52px;
}
	.news__lettersd__top .img-fluid {
	top: 1px;
	width: 166px;
}
	.sg-sidebar.theiaStickySidebar .sg-widget.widget-social {
	margin-bottom: 0px;
}
	.sg-sidebar.theiaStickySidebar .widget-social ul li {
	width: 50%;
	float: left;
	margin-bottom: 0px;
	font-size: 12px;
	overflow: hidden;
	text-align: center;
}
	
	.widget-social ul li:nth-child(2n+1) {
	padding-right: 0px;
}
	
	.news__lettersd__top .entry-title.dse {
	text-align: left;
	color: #000;
	font-size: 19px;
	margin-bottom: 36px;
	font-weight: 600;
}
	
	.footer.footer-style-1 {
	float: left;
	width: 100%;
}
	.news__lettersd {
	float: left;
	width: 100%;
}
	
	.news__lettersd__top .widget-social ul li span {
	width: 47px;
	height: 56px;
	line-height: 35px;
	display: block;
	text-align: center;
	color: #fff;
	font-size: 20px;
	float: left;
	padding-top: 18px;
	position: relative;
	/* top: 5px; */
}
	
	.news__lettersd__top .sg-socail {
	margin-top: -17px;
	margin-right: -15px;
}
	
		.news__lettersd__top .sg-sidebar.theiaStickySidebar .widget-social ul li {
	width: 50%;
	float: left;
	margin-bottom: 0px;
	font-size: 12px;
	overflow: hidden;
	text-align: center;

}
	.news__lettersd__top .widget-social ul li:nth-child(2n+1) {
	padding-right: 0px;
}
	
	.news__lettersd__top  .widget-social ul li:nth-child(2n) {
	padding-left: 0px;
}
	
	.news__lettersd .sg-sidebar.theiaStickySidebar {
	width: 100%;
}
	
	.news__lettersd__top {
	display: none;
}
	.news__lettersd__top.sticky {
	display: block;
}
	
	.global-list.s__00f123 li a {
	color: #000;
	font-size: 32px;
	background: transparent;
	box-shadow: none;
}
	.socilamedias__123430 {
	float: left;
	width: 100%;
	margin-top: 44px;
}
.socilamedias__123430 h3 {
	font-size: 16px;
	color: #000;
	margin-bottom: 22px;
}
	
	.post-details .sg-socail li a {

	box-shadow: none!important;
}
	
.contents__002412 h3 {
	font-size: 14px;
	font-weight: 500;
	margin-top: 18px;
	padding-bottom: 15px;
}
	
	.sg-page-content {
	padding-top: 103px;
	padding-bottom: 30px;
}
	
	.sg-post {
	position: relative;
	overflow: hidden;
	margin-bottom: 30px;
	background-color: transparent!important;
	
}
	.entry-content.p-4.add__class__088 {
	position: relative;
	z-index: 99;
	background: transparent!important;
}
	.contact-form, .sg-comments-area, .tagcloud-style-1 {
	padding: 3px;
	background-color: transparent!important;
	
}
	
	.tagcloud-style-1 a {
	border-radius: 20px;
	padding: 5px 20px;
	margin-top: 8px;
	margin-bottom: 8px;
	margin-right: 15px;
	display: inline-block;
	background-color: #eae0e0!important;
}
	
	.post-details .sg-socail li a {
	padding: 5px 15px;
	color: #707070;
	display: block;
	border-radius: 4px;
	background-color: transparent!important;
	
}
	.views__relaed {
	background: transparent;
	padding-top: 53px;
}
	.views__relaed .container {
	width: 58%;
}
	
	.owl-carousel .item {
	position: relative;
	z-index: 100;
	-webkit-backface-visibility: hidden;
	background: #fff;
}
	.news__lettersd {
	float: left;
	width: 100%;
	background: transparent!important;
}
.sg-page-content {
	float: left;
	width: 100%;
	background: #fff;
}
	.views__relaed {
	background: #fff;
	padding-top: 53px;
}
	
	.news__lettersd {
	float: left;
	width: 100%;
	background: #fff !important;
}
	
	.views__relaed {
	background: #fff;
	padding-top: 53px;
	float: left;
	width: 100%;
}
		.post-style-2 .entry-title a {
	color: #000 !important;
	font-size: 13px;
	height: 74px;
	display: inline-block;
	margin-top: -31px;
	padding: 0px;
}
	.post-style-2 .entry-title a {
	color: #000 !important;
	font-size: 13px;
	height: 74px;
	display: inline-block;
	margin-top: -31px;
	padding: 0px;
	text-align: left;
	line-height: 19px;
}

	.rightads {
	position: fixed;
	right: 101px;
}
	.leftads {
	position: fixed;
	left: 95px;
}
	.topads img {
	box-shadow: 0 0 4px 2px #0000004f;
}
	
	.leftads img {
	box-shadow: 0 0 2px 3px #0000003d;
}
	
	.rightads img {
	box-shadow: 0 0 2px 3px #0000003d;
}
    
    .news__lettersd__top .entry-title.dse {
	text-align: left;
	color: #000;
	font-size: 15px;
	margin-bottom: 36px;
	font-weight: 600;
	margin-top: -4px;
}

a.biosimilars {
    background: #64af4c;
}
.events__details__0812 strong {
	float: left;
	width: 100%;
}
	
	.events__details__0812 .node__content {
	text-align: justify;
}
	.sg-post .entry-content {
	padding: 12px 16px;
	font-size: 14px;
	height: 107px!important;
}

a.Top-20 {
    background: #246b8d;
    color: #fff !important;
}

a.insight {
    background: #173c3c;
}

a.events {
    background: #0a0a0a;
}
    .datesdsf .global-list {
    margin-top: -7px!important;
}
    @media  screen and (min-width:320px) and (max-width:767px){
        .views__relaed {
        padding-bottom:53px;
}
       .views__relaed .container {
    width: 90%!important;
}
        .datesdsf .global-list {
    text-align: left;
    display: inline-block;
    font-size: 19px !important;
    margin-bottom: 19px;
    margin-top: -8px!important;
}
        .author-info h2 {
    font-size: 12px!important;
}
.entry-meta.mb-2 {
    margin-left: 26px!important;
}
</style>

	







<?php $__env->startSection('style'); ?>

    <link rel="stylesheet" href="<?php echo e(static_asset('site/css/plyr.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(static_asset('reaction/reaction.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(static_asset('reaction/reaction-2.css')); ?>" />

<!--

<div class="header">
  <h2>Scroll Indicator</h2>
  <div class="progress-container">
    <div class="progress-bar" id="myBar"></div>
  </div>  
</div>
-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  


<section class="news__lettersd__top" id="myHeader">
	<div class="container">
		
	
		
		
	<div class="row">
<div class="col-md-2">
		
		<div class="logo__s_12">
	<a class="navbar-brand align-self-center" href="<?php echo e(route('home')); ?>"><img style="position: relative;
left: -7px;" src="<?php echo e(static_asset(settingHelper('logo'))); ?>" alt="Logo" class="img-fluid"></a>
	</div>
		</div>
		
		<div class="col-md-8">
			
			
			
			
			
		<div class="heading__name12">
			<h3 class="entry-title dse"><?php echo $post->title ?? ''; ?></h3>
			</div>
		</div>
  <div class="col-md-2 col-lg-2">

                    <div class="sg-sidebar theiaStickySidebar">
<div class="s__00__0">
	<span style="text-transform: uppercase;
font-size: 12px;">Share this</span>
						
						</div>
						<div class="c__set__0d">
                            <div class="sharethis-inline-share-buttons"></div>
							</div>

                    </div>

                </div>
		</div>
			</div>
</section>


    <div class="sg-page-content">



			<!-- <div class="leftads">
				<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($ads_AdLocations->unique_name == 'single_post_left'): ?>
						<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
						<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
								<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">	
							</a>	
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
							<?php echo e($ads_AdLocations->ad->ad_code); ?>	
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
							<div class="textads">
								<?php echo e($ads_AdLocations->ad->ad_text); ?>

							</div>	
						<?php endif; ?>
					<?php endif; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div> -->


			<!-- <div class="rightads">
				<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($ads_AdLocations->unique_name == 'single_post_right'): ?>
						<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
						<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
								<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">	
							</a>
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
							<?php echo e($ads_AdLocations->ad->ad_code); ?>	
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
							<div class="textads">
								<?php echo e($ads_AdLocations->ad->ad_text); ?>

							</div>	
						<?php endif; ?>
					<?php endif; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div> -->

        <div class="container events__details__0812">

            <div class="entry-header mb-4">

			

	<!-- <div class="topads">
	
				<?php $__currentLoopData = $ads_AdLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ads_AdLocations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($ads_AdLocations->unique_name == 'single_post_top'): ?>
						<?php if($ads_AdLocations->ad->ad_type == 'image'): ?>
							<a href="<?php echo e($ads_AdLocations->ad->ad_url); ?>">
								<img src=" <?php echo e(static_asset($ads_AdLocations->ad->adImage->original_image)); ?>" alt="" style="">	
							</a>
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'code'): ?>
							<?php echo e($ads_AdLocations->ad->ad_url); ?>	
						<?php endif; ?>

						<?php if($ads_AdLocations->ad->ad_type == 'text'): ?>
							<div class="textads">
								<?php echo e($ads_AdLocations->ad->ad_text); ?>

							</div>	
						<?php endif; ?>
					<?php endif; ?>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div> -->

                <div class="entry-thumbnail">

                    <!-- <?php if($post->layout == 'style_3'): ?>
                        <?php echo $__env->make('site.pages.event.partials.detail_image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?> -->
					

                </div>

            </div>

            <div class="row">

                <div class="col-md-12 col-lg-12 sg-sticky">

                    <div class="theiaStickySidebar post-details">

                        <div class="sg-section">

                            <div class="section-content gdg_-0-09">

                                <div class="sg-post">

                                    <?php if($post->layout =='default'): ?>

                                        <?php echo $__env->make('site.pages.event.style_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <?php elseif($post->layout == 'style_2'): ?>

                                        <?php echo $__env->make('site.pages.event.style_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <?php elseif($post->layout == 'style_3'): ?>

                                        <?php echo $__env->make('site.pages.event.style_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <?php endif; ?>

                                </div>

                                

<div class="socilamedias__123430">
												<h3>Share this article on WhatsApp, LinkedIn and Twitter</h3>
													
													
													<div class="sg-socail">
		
							<div class="sharethis-inline-share-buttons"></div>


							
			</div>
			</div>

                               
<!--                               -->






                            </div>

                        </div>

                    </div>
					
					
					
					

                </div>



              



            </div>

        </div>

    </div>
<br><br>


<section class="news__lettersd" id="news__lettersid" >
	<div class="container">
	<div class="row">

  <div class="col-md-12 col-lg-12 ">

                    <div class="sg-sidebar theiaStickySidebar">

                        <?php echo $__env->make('site.partials.right_sidebar_widgets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>

                </div></div>
			</div>
</section>

<div class="popup__show">
	<div class="s__0544">
	X
	</div>
<div class="popup__all__contents">
	

	<div class="img__0912">
	<img src="<?php echo e(url('/')); ?>/public/site/images/subscribe_now.png" />
	</div>
	
	<div class="contents__002412">
	<h3>Liked our insights or summarized news?</h3>
        <p>Subscribe to our Daily/Weekly newsletter</p>
		<p class="readmore__097"><a href="#news__lettersid">Subscribe</a></p>
	</div>
	</div>

</div>
  

    <input type="hidden" id="url" value="<?php echo e(url('/')); ?>">

    <input type="hidden" id="post_id" value="<?php echo e($post->id); ?>">



<?php $__env->stopSection(); ?>



<?php $__env->startSection('player'); ?>

    <script src="<?php echo e(static_asset('site/js')); ?>/plyr.js"></script>

    <script src="<?php echo e(static_asset('site/js')); ?>/plyr_ini.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>



<script>



    $(".emoji-2").on("click", function () {

        var url = $('#url').val();



        $('[data-toggle="tooltip"]').tooltip();



        var formData = {

            data_reaction: $(this).attr("data-reaction"),

            id: $('#post_id').val()

        };



        // get section for student

        $.ajax({

            type: "GET",

            data: formData,

            dataType: 'json',

            url: url + '/' + 'post/reaction',

            success: function (data) {



                console.log(data['reactions']);

                console.log(data['is_you']);



                if(data['total'] == 0){



                    $('.like-details').html('Like');



                }else if(data['is_you'] != null){



                    var total = data['total'] - 1;



                    $('.like-details').html(' you and '+ total + ' others');



                }else{



                    $('.like-details').html(data['total']+ ' others');



                }



                console.log(data['is_you']);



                if(data['is_you'] == null || data['is_you']['data_reaction'] == 'Like'){

                    $('.like-emo span').removeAttr('class');

                    $('.like-emo span').attr('class', 'like-btn-like');

                }else if(data['is_you']['data_reaction'] == 'Love'){

                    $('.like-emo span').removeAttr('class');

                    $('.like-emo span').attr('class', 'like-btn-love');

                }else if(data['is_you']['data_reaction'] == 'HaHa'){

                    $('.like-emo span').removeAttr('class');

                    $('.like-emo span').attr('class', 'like-btn-haha');

                }else if(data['is_you']['data_reaction'] == 'Wow'){

                    $('.like-emo span').removeAttr('class');

                    $('.like-emo span').attr('class', 'like-btn-wow');

                }else if(data['is_you']['data_reaction'] == 'Sad'){

                    $('.like-emo span').removeAttr('class');

                    $('.like-emo span').attr('class', 'like-btn-sad');

                }else if(data['is_you']['data_reaction'] == 'Angry'){

                    $('.like-emo span').removeAttr('class');

                    $('.like-emo span').attr('class', 'like-btn-angry');

                }



                jQuery.each( data['reactions'], function( key, val ) {



                    if(key == "Like"){

                        $('.emo-like-2').attr('data-original-title', 'Like '+val);

                    }

                    if(key == "Love"){

                        $('.emo-love-2').attr('data-original-title', 'Love '+val);

                    }

                    if(key == "HaHa"){

                        $('.emo-haha-2').attr('data-original-title', 'HaHa '+val);

                    }

                    if(key == "Wow"){

                        $('.emo-wow-2').attr('data-original-title', 'Wow '+val);

                    }

                    if(key == "Sad"){

                        $('.emo-sad-2').attr('data-original-title', 'Sad '+val);

                    }

                    if(key == "Angry"){

                        $('.emo-angry-2').attr('data-original-title', 'Angry '+val);

                    }



                });





                var reactions = ['Like', 'Love', 'HaHa', 'Wow', 'Sad', 'Angry'];



                jQuery.each( reactions, function( key, val ) {



                    if (!data['reactions'].hasOwnProperty(val)) {

                        $('.emo-'+val.toLowerCase()+'-2').attr('data-original-title', val + ' 0');

                    }



                });



                $('[data-toggle="tooltip"]').tooltip();





            },

            error: function (data) {

            // console.log('Error:', data);

            }

        });

    });



        $(document).ready(function(){

            $('[data-toggle="tooltip"]').tooltip();

        });



</script>


<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('site.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/site/pages/event_detail.blade.php ENDPATH**/ ?>