
<?php /**PATH /var/www/html/resources/views/site/pages/event/partials/content.blade.php ENDPATH**/ ?>