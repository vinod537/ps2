
<?php /**PATH /var/www/html/resources/views/vendor/feed/links.blade.php ENDPATH**/ ?>