<?php

return array (
  'previous' => '&laquo; Previous',
  'next' => 'Next &raquo;',
);
