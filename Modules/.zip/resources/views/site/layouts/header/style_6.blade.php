<style>
    

    @media screen and (min-width:1100px) and  (max-width:1550px){
   .search-form.d__rtt.new_drtt {
    position: absolute;
    top: 28px!important;
    right: 3px!important;
}
        
.contasffiner {
    margin-left: -14px;
}

   }

    @media screen and (min-width:360px) and (max-width:800px){
    .search-form.d__rtt.new_drtt {
	margin-right: -19px !important;
}
         .header-bottom.header_top.sticky {
    background: #fff;
    height: 96px!important;
}

        .menu-content {
	margin-top: -9px !important;
	margin-left: 19px !important;
}

        .col-md-2asfasf.new_search_on {
	margin-right: 29px !important;
	margin-top: -8px !important;
}
        .col-md-2asfasf {
	
right:0px !important;

}
        .search-form.d__rtt.new_drtt  #label {
	border-radius: 21px !important;
}
    }
    #headdf .container {
	max-width: 98%!important;
}
    @media screen and (min-width:1100px) and (max-width:1500px){
      .col-md-2asfasf .search-form.d__rtt {
	margin-top: -33px !important;
        }
}
    @media screen and (min-width:320px) and (max-width:767px){
    .navbar-brand {
	margin-top: 0px!important;
}
        .sg-menu.menu-style-1 {
    position: relative;
    z-index: 9!important;
}
        
       
.sidebar {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #fff;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
  
}
.navbar-nav {
	text-align: left;
}
.sidebar a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidebar a:hover {
  color: #f1f1f1;
}

.sidebar .closebtn {
	position: absolute;
	top: 24px;
	right:9px;
	font-size: 22px;
	margin-left: 50px;
	color: #000;
}

.openbtn {
	font-size: 17px;
	cursor: pointer;
	background-color: transparent;
	color: #000;
	padding: 3px 7px;
	border: 1px solid #000;
}

.openbtn:hover {
  background-color: #444;
}

#main {
  transition: margin-left .5s;
  padding: 16px;
}
    }
    
    
    

	.sg-search {
	margin-left: 0px;
}
.sg-search {
	margin-left: 0px;
	width: 63%;
	padding-top: 3px;
}

	.navbar-brand {
	max-width: 230px;
	margin-top: -12px;
}
.header-bottom {
	padding: 23px 0;
	background-color: transparent;
	padding-bottom: 1px;
	position: absolute;
	width: 100%;
}
	.sg-user.pull-right {
	padding-top: 9px;
	text-transform: uppercase;
	font-size: 13px;
}

	.sg-post .category ul li a, a.read-more {
	color: #fff;
	display: block;
	padding: 3px 10px;
	background-color: #EF3C0E;
	border-radius: 39px;
}
	

	
	.sg-user.pull-right {
	padding-top: 15px;
	text-transform: uppercase;
	font-size: 13px;
}
	.sg-menu .navbar-nav li a:hover, .sg-menu .navbar-nav li.active > a {
	background-color: transparent;
	border-bottom: none;
}
.sg-menu .navbar-nav li a {
	color: #222;
	display: block;
	font-weight: 400;
	padding: 9px 0 12px 1px;
	margin-right:20px;
	font-size: 13px;
	text-transform: uppercase;
	letter-spacing: 1px;
}
	.navbar.navbar-expand-lg {
	background: transparent!important;
}
	
	.sg-menu {
	margin-bottom: 30px;
	background-color: transparent;

	box-shadow: none;
}
	.navbar-nav {
	display: -ms-flexbox;
	display: flex;
	-ms-flex-direction: column;
	flex-direction: column;
	padding-left: 0;
	margin-bottom: 0;
	list-style: none;
	margin-left: auto;
	margin-right: auto;
}


.header-bottom .form-control {
	height: 37px;
	border-radius: 50px;
	padding: 1px 15px;
	margin-bottom: 19px;
	border: 1px solid #d8e2e9;
	position: relative;
	top: 4px;
	background: transparent;
	border: none;
	border-bottom: 1px solid #fff;
	border-radius: 0px !important;
	color: #fff !important;
	padding-left: 0px;
}
	#search button {
	/* position: relative; */
	top: ;
	top: 13px;
	right: 14px;
}
    .d-none-small a {
	padding: 10px 20px 10px 20px;
}
.style-3 {
	background: #073c65;
	color: #fff;
	padding: 8px 0px 9px 0px;
	border-radius: 6px;
}
    .style-3 .dropdown {
	padding: 0px 7px 0px 7px;
}
	.style-3 a {
	color: #fff;
}
	.sg-user.pull-right {
	padding-top: 0px;
	text-transform: uppercase;
	font-size: 13px;
}
	.navbar-brand {
	max-width: 230px;
	margin-top: -7px;
}
	
	.col-md-2asfasf {
	position: absolute;
	right: 0px;
	float: right;
	text-align: right;
}
	.s_0f {
	text-align: center;
	color: #fff;
	text-transform: uppercase;
	margin-bottom: 100px;
	letter-spacing: 1px;
}
	.sg-search .form-control:focus {
	border-color: #fff!important;
}
	
	.col-md-2asfasf .sg-search {
	margin-left: 0px;
	width: 100%;
	padding-top: 3px;
}
	

.col-md-2asfasf .search-form.d__rtt {
	width: 251px;
	right: 20px;
	margin-top: -34px;
	position: absolute;
	z-index: 9999;
}
	#search button {
	/* position: relative; */
	top: ;
	top: 8px;
	right: 11px;
}
	
	.search-form.d__rtt {
	display: none;
}
	.search__click_09 {
	/* position: relative; */
	/* z-index: 9999; */
	cursor: pointer;
}
	
	.col-md-2asfasf {
	position: absolute;
	right: -64px;
	float: right;
	text-align: right;
	top: 5px;
	z-index: 99;
}
	
	@media screen and (min-width:320px) and (max-width:767px){
		
				.col-md-2asfasf.new_search_on.ppoojhgh #label {
	border-radius: 0px !important;
	font-size: 15px;
}
.text-center.new_text {
	text-align: left !important;
	position: absolute;
	z-index: 99;
}
		.entry-title {
	height: auto !important;
	margin-bottom: 23px;
}
		.sg-post .entry-content {
	padding: 12px 16px;
	font-size: 14px;
	height: auto;
}
		.theiaStickySidebar .sg-post .entry-content {
	padding: 12px 16px;
	font-size: 14px;
	height: auto;
}   
		.owl-dots {
	text-align: center;
	margin-top: 0px;
	position: relative;
	z-index: 9999;
}
	}
	
	  
    .banner__s.d__059i.new_slider .container {
	width: inherit!important;
}
.loader {
	position: fixed;
	background: #fffffffa;
	width: 100%;
	text-align: center;
	z-index: 999999999;
	height: 100%;
	padding: 259px 0px;
}
	.loader img {
	width: 18%;
}
</style>

    
<div class="loader">
 <img src="{{static_asset('images/pharmashots_loader.gif') }}" />
	
   
	
</div>
<header class="sg-header">
<!--
    <div class="sg-topbar topbar-style-1">
        <div class="container">
            <div class="d-md-flex justify-content-md-between">
                <div class="left-contennt d-flex d-flex-style-3">
                    <div class="weather-content d-flex mr-5">
                        <div class="date">
                            <span><i class="fa fa-calendar mr-2" aria-hidden="true"></i>{{date('l, d F Y')}}</span>
                        </div>
                    </div>
                </div>
               
                <div class="right-content d-flex align-self-center">
                    @if(settingHelper('submit_news_status')==1)
                        <div class="d-flex">
                            <div class="submit-news d-none d-md-block">
                                <a href="{{ route('submit.news.form') }}">{{__('submit_now')}}</a>
                            </div>
                        </div>
                    @endif
                    <div class="sg-language">
                        <select name="code" id="languges-changer">
                            @foreach ($activeLang as $lang)
                                <option value="{{$lang->code}}" {{ LaravelLocalization::setLocale() == ""? ( settingHelper('default_language') == $lang->code? 'selected':'' ) : (LaravelLocalization::setLocale() == $lang->code ? 'selected':'') }}>{{ $lang->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="sg-social d-none d-md-block mr-4">
                        <ul class="global-list">
                            @foreach($socialMedias as $socialMedia)
                                <li><a href="{{$socialMedia->url}}" target="_blank"><i class="{{$socialMedia->icon}}" aria-hidden="true"></i></a></li>
                            @endforeach
                            <li><a href="{{ url('feed') }}"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                      
                </div>
            </div>
        </div>
    </div>
-->
    <div class="header-bottom header_top" id="headdf">
        <div class="container">
			<div class="row">
				
			
			<div class="col-md-3 col-xs-7">
            <div class="text-center new_text" style="text-align: center;">
                <a class="navbar-brand align-self-center" href="{{ route('home') }}">
					<img style="position: relative;
left: -7px;" src="{{ static_asset(settingHelper('logo')) }}" alt="Logo" class="img-fluid"></a>
            </div>
			</div>
				
				<div class="col-md-7 col-xs-3">
				 <div class="sg-menu menu-style-1">
        <nav class="navbar navbar-expand-lg new__button">
            <div class="contasffiner">
                <div class="menu-content new_tab_menu">
<!--
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"><i class="fa fa-align-justify"></i></span>
                    </button>
-->

                     <button class="openbtn" onclick="openNav()">☰ </button>  
<!--                    <div class="collapse navbar-collapse" id="navbarNav">-->
                        <div id="mySidebar" class="sidebar">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
                        <ul class="navbar-nav">

                            @foreach($primaryMenu as $mainMenu)

                                @if($mainMenu->is_mega_menu == 'no')
                                    <li class="nav-item sg-dropdown">
                                        <a href="{{menuUrl($mainMenu)}}" target="{{$mainMenu->new_teb == 1? '_blank':''}}">{{$mainMenu->label == 'gallery'? __('gallery'):$mainMenu->label}} @if(!blank($mainMenu->children))<span><i class="fa fa-angle-down" aria-hidden="true"></i></span>@endif </a>
                                        <ul class="sg-dropdown-menu">
                                            @foreach($mainMenu->children as $child)
                                                <li class=""><a href="{{menuUrl($child)}}" target="{{$child->new_teb == 1? '_blank':''}}">{{@$child->label}} @if(!blank($child->children)) <span class="pull-right"><i class="fa fa-angle-right" aria-hidden="true"></i></span>@endif</a>
                                                    <ul class="sg-dropdown-menu-menu">
                                                        @foreach($child->children as $subChild)
                                                            <li class=""><a href="{{menuUrl($subChild)}}" target="{{$subChild->new_teb == 1? '_blank':''}}">{{@$subChild->label}}</a></li>
                                                        @endforeach
                                                    </ul>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </li>
                                @endif

                                @if($mainMenu->is_mega_menu == 'tab')

                                    <li class="sg-dropdown mega-dropdown">
                                        <a href="{{menuUrl($mainMenu) ? menuUrl($mainMenu) : "#" }}">{{$mainMenu->label == 'gallery'? __('gallery'):$mainMenu->label}}<span><i class="fa fa-angle-down" aria-hidden="true"></i></span></a>
                                        <div class="sg-dropdown-menu mega-dropdown-menu">
                                            <div class="mega-menu-content">
                                                <div class="row">
                                                    <div class="col-md-2">
                                                        <ul class="nav nav-tabs" role="tablist">
                                                            @foreach($mainMenu->children as $child)
                                                                @php $key = 0 @endphp
                                                                    <li class="nav-item">
                                                                        <a class="nav-link {{$mainMenu->children[$key]->id == $child->id? 'active':''}}" id="{{$child->label}}-tab" data-toggle="tab" href="#{{$child->category->slug}}" role="tab" aria-controls="{{$child->label}}" aria-selected="{{$mainMenu->children[$key]->id == $child->id? 'true':'false'}}">{{$child->label == 'gallery'? __('gallery'):$child->label}}</a>
                                                                    </li>
                                                                @php $key++ @endphp
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                    <div class="col-md-10">
                                                        <div class="tab-content" id="myTabContent">
                                                            @foreach($mainMenu->children as $child)
                                                                <div class="tab-pane fade {{$mainMenu->children[0]->id == $child->id? 'show active':''}}" id="{{$child->category->slug}}" role="tabpanel" aria-labelledby="{{$child->label}}-tab">
                                                                    <div class="row">
                                                                        @foreach($child->postByCategory as $item)
                                                                            <div class="col-md-6 col-lg-3">
                                                                                <div class="sg-post">
                                                                                    <div class="entry-header">
                                                                                        <div class="entry-thumbnail">
                                                                                            <a href="{{ route('article.detail', ['id' => $item->slug]) }}">
                                                                                                @if(isFileExist(@$item->image, $result = @$item->image->medium_image_three))
                                                                                                    <img class="img-fluid" src="{{ safari_check() ? basePath(@$item->image).'/'.$result : static_asset('default-image/default-240x160.png') }}" data-original="{{basePath(@$item->image)}}/{{ $result }}" alt="{!! $item->title !!}">
                                                                                                @else
                                                                                                    <img class="img-fluid" src="{{static_asset('default-image/default-240x160.png') }}"  alt="{!! $item->title !!}">
                                                                                                @endif
                                                                                            </a>
                                                                                        </div>
                                                                                        @if($item->post_type=="video")
                                                                                            <div class="video-icon block">
                                                                                                <img src="{{static_asset('default-image/video-icon.svg') }} " alt="video-icon">
                                                                                            </div>
                                                                                        @elseif($item->post_type=="audio")
                                                                                            <div class="video-icon block">
                                                                                                <img src="{{static_asset('default-image/audio-icon.svg') }} " alt="audio-icon">
                                                                                            </div>
                                                                                        @endif
                                                                                    </div>
                                                                                    <div class="entry-content">
                                                                                        <a href="{{ route('article.detail', ['id' => $item->slug]) }}"><p>{!!Str::limit( $item->title , 35)!!}</p></a>
                                                                                        <div class="entry-meta">
                                                                                            <ul class="global-list">
                                                                                               <li>{{ __('post_by') }} <a href="{{ route('site.author',['id' => $item->user->id]) }}">{{$item->user->first_name}} </a> <a href="{{route('article.date', date('Y-m-d', strtotime($item->updated_at)))}}"> {{date('d F Y', strtotime($item->created_at))}}</a></li>
                                                                                            </ul>
                                                                                        </div><!-- /.entry-meta -->
                                                                                    </div><!-- /.entry-content -->
                                                                                </div><!-- /.sg-post -->
                                                                            </div>
                                                                        @endforeach
                                                                    </div><!-- /.row -->
                                                                </div><!-- /.tab-pane -->
                                                            @endforeach
                                                        </div><!-- /.tab-content -->
                                                    </div>
                                                </div><!-- /.row -->
                                            </div><!-- /.mega-menu-content -->
                                        </div>
                                    </li>
                                @endif

                                @if($mainMenu->is_mega_menu == 'category')
                                    <li class="sg-dropdown mega-dropdown">
                                        <a href="{{menuUrl($mainMenu)}}" target="{{$mainMenu->new_teb == 1? '_blank':''}}">{{$mainMenu->label == 'gallery'? __('gallery'):$mainMenu->label}} @if(!blank($mainMenu->children))<span><i class="fa fa-angle-down" aria-hidden="true"></i></span>@endif</a>
                                        <div class="sg-dropdown-menu mega-dropdown-menu">
                                            <div class="mega-menu-content">
                                                <div class="row">
                                                    @foreach($mainMenu->children as $child)
                                                        <div class="col-md-3">
                                                            <h3>{{$child->label == 'gallery'? __('gallery'):$child->label}}</h3>
                                                            <ul class="global-list">
                                                                 @foreach($child->children as $subChild)
                                                                    <li><a href="{{menuUrl($subChild)}}" target="{{$subChild->new_teb == 1? '_blank':''}}">{{$subChild->label == 'gallery'? __('gallery'):$subChild->label}}</a></li>
                                                                 @endforeach
                                                            </ul>
                                                        </div>
                                                    @endforeach
                                                </div><!-- /.row -->
                                            </div><!-- /.mega-menu-content -->
                                        </div>
                                    </li>
                                @endif

                            @endforeach
                        </ul>
                    </div>

                 
                </div><!-- /.menu-content -->
            </div><!-- /.container -->
        </nav><!-- /.navbar -->
    </div>
					
					
						<div class="col-md-2asfasf new_search_on ppoojhgh">
				   <div class="sg-search pull-left">
					   
					   <span class="search__click_09"><i class="fa fa-search"></i></span>
                        <div class="search-form d__rtt new_drtt search__popup">
							<span class="close__09123">x</span>
							<h3 class="s_0f">Search category</h3>
                            <form action="{{ route('article.search') }}" id="search" method="GET">
                                <label for="label" class="d-none">{{ __('search') }}</label>
                                <input class="form-control" id="label" name="search" type="text" placeholder="{{ __('search') }}">
                                <button type="submit" name="submit"><i class="fa fa-search"></i><span class="d-none">{{__('search')}}</span></button>
                            </form>
                        </div>
                    </div>
				</div>
					
					
					
					
				</div>
			
			<div class="col-md-2">
			  <div class="sg-user pull-right">
                            <div class="style-3">
                                @if(Cartalyst\Sentinel\Laravel\Facades\Sentinel::check())
                                    <div class="dropdown">
                                        <a class="nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            @if(Sentinel::getUser()->profile_image != null)
                                                <img src="{{static_asset('default-image/user.jpg') }}" data-original="{{static_asset(Sentinel::getUser()->profile_image)}}"  class="profile">
                                            @else
                                                <i class="fa fa-user-circle mr-2"></i>
                                            @endif
                                                {{ Sentinel::getUser()->first_name}} <i class="fa fa-angle-down  ml-2" aria-hidden="true"></i></a>
                                        <div class="dropdown-menu dropdown-menu-right nav-user-dropdown site-setting-area" aria-labelledby="navbarDropdownMenuLink2">
                                            @if(Sentinel::getUser()->roles[0]->id != 4 && Sentinel::getUser()->roles[0]->id != 5)
                                                <a class="" href="{{ route('dashboard') }} " target="_blank"><i class="fa fa-tachometer mr-2" aria-hidden="true"></i>{{__('dashboard')}}</a>
                                            @endif
                                            <a class=""  href="{{ route('site.profile') }}"><i class="fa fa-user mr-2"></i>{{__('profile')}}</a>

                                            <a class=""  href="{{ route('site.profile.form') }}"><i class="fa fa-cog mr-2"></i>{{__('edit_profile')}}</a>

                                            <a class="" href="{{ route('site.logout') }}"><i class="fa fa-power-off mr-2"></i>{{__('logout')}}</a>
                                        </div>
                                    </div>
                                @else
                                    <span>
<!--                                <i class="fa fa-user-circle mr-2" aria-hidden="true"></i>-->
<!--                                <a href="{{ route('site.login.form') }}">{{ __('') }}</a> <span class="d-none-small"><a href="{{ route('site.login.form') }}"> {{ __('Subscribe Now') }}</a></span>-->
                                        <span class="d-none-small"><a href="{{ url('/') }}/#newsletters"> {{ __('Subscribe Now') }}</a></span>
                            </span>
                                @endif
                            </div>
                        </div>
			</div>
				</div>
        </div><!-- /.container -->
    </div><!-- /.header-bottom -->

   
</header><!-- /.sg-header -->
@include('site.partials.ads', ['ads' => $headerWidgets])
