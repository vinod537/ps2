<div class="thumb mb-4">
    <img class="img-fluid" src="{{static_asset('default-image/default-730x400.png') }}" alt="Image">
</div>

