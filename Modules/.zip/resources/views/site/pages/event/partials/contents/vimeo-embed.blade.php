<div class="thumb mb-4">
    {!! $content['vimeo-embed'][0]['vimeo'] !!}
</div>
