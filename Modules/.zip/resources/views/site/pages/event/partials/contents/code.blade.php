<div class="thumb mb-4">
    {!!$content['code'][0]['code']!!}
    
</div>