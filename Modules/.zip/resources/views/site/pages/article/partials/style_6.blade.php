<div class="row mb-4">
    <div class="text mx-3">
        <p class="paragraph">There are many variations of passages of Lorem Ipsum available, but the majority have suffered  believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of to use a passage of Lorem Ipsum, you need </p>
    </div>
</div>
