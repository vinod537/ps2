<div class="thumb mb-4">
    {!! $content['youtube-embed'][0]['youtube'] !!}
</div>