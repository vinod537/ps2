<?php

return [
    'name' => 'Widget'
];
