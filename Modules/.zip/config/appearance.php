<?php

return [
    'name' => 'Appearance'
];
