<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    1 => 'Modules\\Setting\\Providers\\MailConfigServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    1 => 'Modules\\Setting\\Providers\\MailConfigServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);