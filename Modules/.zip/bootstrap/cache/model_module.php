<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Model\\Providers\\ModelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Model\\Providers\\ModelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);