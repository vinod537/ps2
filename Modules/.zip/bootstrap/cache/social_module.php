<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Social\\Providers\\SocialServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Social\\Providers\\SocialServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);