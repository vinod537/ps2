<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Language\\Providers\\LanguageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Language\\Providers\\LanguageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);