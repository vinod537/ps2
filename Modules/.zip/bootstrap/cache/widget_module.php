<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Widget\\Providers\\WidgetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Widget\\Providers\\WidgetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);