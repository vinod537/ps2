<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ads\\Providers\\AdsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ads\\Providers\\AdsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);