<?php
 namespace App\Enums;

 interface GenderType
 {
 	const Male          = 1;
 	const Female    	= 2;
 	const Other   	    = 3;
 }
